//! RAG prompt templates.
//!
//! The Enterprise prompt verbatim, used in the Community build with the same
//! structure minus the structured_data_section, which is empty here.
//!
//! Golden test: the same prompt must produce the same generated text from the
//! same LLM.

pub const QA_PROMPT: &str = r#"/no_think
You are an expert research analyst. Answer based on the data below.

INSTRUCTIONS:
1. STRUCTURE: Start with a direct answer, then provide detailed supporting information with dates, names, locations, context, and explanations.
2. VERIFIED DATA FIRST: Use STRUCTURED DATA as verified facts (dates, event types). Use RETRIEVED CHUNKS for additional context and details.
3. CITATIONS: Cite sources as [Filename] after each fact.
4. SEMANTIC UNDERSTANDING: Recognize that terms may appear in different languages or synonyms (e.g., "attentato" = "attack" = "bombing").
5. THOROUGH: Provide rich, detailed answers. Extract ALL relevant information from the chunks - don't summarize, elaborate. Include background, consequences, related events.
6. LANGUAGE: Respond in the SAME LANGUAGE as the question.
7. NO INVENTION: Only use information present in the data. If inferring a connection, say "possibly related" or "may be connected".

{structured_data_section}

{history_section}

RETRIEVED CHUNKS:
{context}

QUESTION: {question}

ANSWER:"#;

/// Format the history section (last 3 exchanges, 800-char truncation per message).
/// Mirrors the history formatting of the Python implementation.
pub fn format_history(history: &[(String, String)]) -> String {
    let last3: Vec<_> = history.iter().rev().take(3).collect();
    if last3.is_empty() {
        return String::new();
    }
    let mut lines = vec!["CONVERSATION HISTORY:".to_owned()];
    for (user_msg, assistant_msg) in last3.iter().rev() {
        let u = truncate(user_msg, 800);
        let a = truncate(assistant_msg, 800);
        lines.push(format!("User: {u}"));
        lines.push(format!("Assistant: {a}"));
    }
    lines.join("\n")
}

/// Truncates to `max_chars` Unicode CHARACTERS, matching Python's `s[:800]`,
/// which counts code points rather than bytes.
///
/// SECURITY: an earlier version sliced by byte with `&s[..max]`, which panics
/// when `max` lands in the middle of a multibyte character — trivial to
/// trigger with accented characters in a stored message longer than 800 bytes,
/// and reachable from the main query path. `chars().take()` can never split a
/// character.
fn truncate(s: &str, max_chars: usize) -> String {
    s.chars().take(max_chars).collect()
}

/// Build the full prompt string.
pub fn build_prompt(context: &str, question: &str, history: &[(String, String)]) -> String {
    let history_section = format_history(history);
    render(
        QA_PROMPT,
        &[
            ("{structured_data_section}", ""),
            ("{history_section}", &history_section),
            ("{context}", context),
            ("{question}", question),
        ],
    )
}

/// Substitutes each `key` in `template` with its value, in one pass.
///
/// Deliberately not a chain of `str::replace` calls. Each of those scans the
/// string produced by the previous one, so a value that itself contains a
/// later key is substituted too: a document whose text contains the literal
/// `{question}` — a template guide, a config file, this very project — had
/// that token replaced by the user's question, inside the evidence. The
/// retrieved chunks stopped being what the document actually says, and the
/// `{ context }`/`{ question }` markers of an injected history could be
/// rewritten the same way.
///
/// Here `rest` only ever points into `template`, never into what has already
/// been emitted, so an inserted value is appended to the output and never
/// looked at again. Within the template the first occurrence of a key wins,
/// which is the one the author wrote.
fn render(template: &str, values: &[(&str, &str)]) -> String {
    let mut out = String::with_capacity(template.len());
    let mut rest = template;
    // The key that comes first in what is left, whichever it is in the list:
    // taking keys in list order would copy an earlier, different key past it
    // verbatim, leaving that slot unfilled.
    while let Some((at, key, value)) = values
        .iter()
        .filter_map(|&(key, value)| rest.find(key).map(|at| (at, key, value)))
        .min_by_key(|&(at, _, _)| at)
    {
        out.push_str(&rest[..at]);
        out.push_str(value);
        rest = &rest[at + key.len()..];
    }
    out.push_str(rest);
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn truncate_does_not_panic_on_multibyte_boundary() {
        // 800 accented characters = 1600 bytes: the old byte slicing
        // `&s[..800]` used to land mid-way through 'à' → panic. It must cut cleanly.
        let s: String = "à".repeat(1000);
        let out = truncate(&s, 800);
        assert_eq!(out.chars().count(), 800);
        assert!(out.chars().all(|c| c == 'à'));
    }

    #[test]
    fn truncate_counts_chars_not_bytes() {
        // Parity with Python's s[:800]: counts code points, not bytes.
        let s: String = "é".repeat(500); // 500 char, 1000 byte
        assert_eq!(truncate(&s, 800), s); // below threshold in CHARs → unchanged
    }

    #[test]
    fn truncate_short_ascii_unchanged() {
        assert_eq!(truncate("hello", 800), "hello");
    }

    #[test]
    fn format_history_survives_long_accented_message() {
        // The real path: a long, accented stored message must not panic.
        let long = "à".repeat(2000);
        let hist = vec![(long.clone(), long)];
        let out = format_history(&hist);
        assert!(out.contains("CONVERSATION HISTORY:"));
    }

    /// The shape the template is supposed to produce, pinned so the one-pass
    /// substitution below cannot quietly change the prompt.
    #[test]
    fn the_prompt_is_the_template_with_its_four_slots_filled() {
        let out = build_prompt("[report.pdf]\nRevenue grew.", "How much?", &[]);
        assert!(!out.contains("{structured_data_section}"), "{out}");
        assert!(!out.contains("{history_section}"), "{out}");
        assert!(
            out.contains("RETRIEVED CHUNKS:\n[report.pdf]\nRevenue grew."),
            "{out}"
        );
        assert!(out.contains("QUESTION: How much?"), "{out}");
        assert!(
            out.starts_with("/no_think\nYou are an expert research analyst."),
            "{out}"
        );
        assert!(out.ends_with("ANSWER:"), "{out}");
    }

    /// The bug: evidence is untrusted input, and it is substituted before the
    /// question. A chain of `replace` calls rewrote the token inside it.
    #[test]
    fn a_placeholder_inside_a_retrieved_chunk_is_left_alone() {
        let chunk = "To render a field use {context}, then {question}.";
        let out = build_prompt(chunk, "What is the revenue?", &[]);
        assert!(
            out.contains("To render a field use {context}, then {question}."),
            "the chunk was rewritten: {out}"
        );
        assert!(
            out.contains("QUESTION: What is the revenue?"),
            "the template's own slot went unfilled: {out}"
        );
    }

    /// Same, one step earlier in the chain: a stored message that happens to
    /// contain a later key.
    #[test]
    fn a_placeholder_inside_the_history_is_left_alone() {
        let history = vec![(
            "How do I use {context}?".to_owned(),
            "It is filled in already.".to_owned(),
        )];
        let out = build_prompt("Revenue grew.", "And now?", &history);
        assert!(out.contains("User: How do I use {context}?"), "{out}");
        assert!(out.contains("Assistant: It is filled in already."), "{out}");
    }

    /// A value carrying a key for a slot that comes *before* it in the
    /// template must not be re-scanned either.
    #[test]
    fn a_value_containing_an_earlier_key_is_not_resubstituted() {
        let out = build_prompt("see {history_section}", "q", &[]);
        assert!(out.contains("see {history_section}"), "{out}");
        assert!(!out.contains("CONVERSATION HISTORY"), "{out}");
    }

    /// A key absent from the template is simply not substituted, and text
    /// with no key at all is copied through untouched.
    #[test]
    fn render_copies_what_it_does_not_fill() {
        assert_eq!(render("a{b}c", &[("{b}", "B")]), "aBc");
        assert_eq!(render("abc", &[("{b}", "B")]), "abc");
        assert_eq!(render("a{b}c", &[("{z}", "Z")]), "a{b}c");
        assert_eq!(render("", &[("{b}", "B")]), "");
    }

    /// Keys out of the list's order are all filled: whichever comes first in
    /// the template is substituted first.
    #[test]
    fn keys_are_filled_in_the_order_they_appear_in_the_template() {
        assert_eq!(
            render(
                "Q: {question}\nC: {context}",
                &[("{context}", "CTX"), ("{question}", "Q?")]
            ),
            "Q: Q?\nC: CTX"
        );
    }
}
