# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

> **On the version numbers.** `1.0.0` to `1.2.1` are the Python stack,
> preserved on the [`python-legacy`](../../tree/python-legacy) branch and no
> longer developed. `0.1.x` is the Rust rewrite that replaced it: a new codebase,
> which restarts the numbering at `0.1` because its storage layout and HTTP
> surface are not settled yet. So the newer line carries the *lower* number —
> see [Upgrading from 1.x](README.md#upgrading-from-1x).

---

## [Unreleased]

Entries for the next release live in [`changelog.d/`](changelog.d/), one
file per change, assembled into a version section here by
`scripts/release-changelog.sh` when the version is cut. Keeping them in
separate files is what stops two pull requests colliding in this one.

---

## [0.1.47] - 2026-10-02

### Added

- **The vectors can take 8 or 16 times less RAM: `QDRANT__QUANTIZATION`.**
  With `turbo4`, Qdrant keeps a TurboQuant copy of every vector in RAM —
  520 bytes instead of 4 KiB at 1024 dimensions — and moves the originals to
  disk. Each search picks its candidates on the compressed copies and
  re-scores twice as many as it returns on the originals; `turbo2` halves
  the RAM again and re-scores four times as many. The results are nearly
  always those of a full-precision search, not always: a chunk the
  compression ranks below that shortlist is never re-scored, so it is
  missed — most likely one nearly tied with others near the bottom of the
  list. On a synthetic test of 30,000 vectors, `turbo4` kept all of the top
  15 results and `turbo2` 99% of them; try it with `--bench` on your own
  documents before relying on it. `off`, the default, keeps every vector in
  RAM as before. The setting is applied to the existing collection at
  startup, and undone the same way; Qdrant re-encodes the vectors in the
  background while searches go on. Needs Qdrant 1.18 or later, which is
  what the bundle ships.

### Changed

- **Searches go through Qdrant's Query API.** The Search API they used is
  deprecated, and Qdrant's 1.19 release notes announce its removal — 1.19.1
  still answers it, but the next update may not. Same results, nothing to
  do on upgrade; checked against the bundled Qdrant 1.18.2 and against
  1.19.1.

- **`spin` 0.9.9 replaces 0.9.8, which is yanked.** Its author yanked
  every earlier 0.9 release when 0.9.9 came out in July, without saying
  why, and no advisory names it. It reaches this server through axum's
  multipart parser and sqlx's SQLite driver. A patch bump in
  `Cargo.lock`; no code changed.

### Fixed

- **A bad backup archive is now reported as a bad request, with its
  reason.** Picking the wrong archive, restoring one whose digest does not
  match, one missing a member, or one taken from a collection this
  installation is not configured for, was answered `500` — and a 5xx's message
  is deliberately withheld, so the admin was told "internal server error" and
  nothing about which archive or why. The classification now also reads the
  whole error chain, so a `.context()` added in the service cannot quietly
  demote a 4xx into a 5xx, and a test holds every refusal the service can
  produce so a new one has to be classified deliberately.

- **The admin panel's vector listing no longer stops at the first page.**
  It asked Qdrant once for a fixed 10,000 points, but the limit counts chunks,
  not documents, and a document is a few dozen of those. Past it the list simply
  ended — and the sync check below it then reported every document past that
  point as "in SQLite but not in Qdrant", listing healthy, fully-present
  documents for deletion. The scroll is now followed to the end.

- **A refused Qdrant reply is no longer shown as the collection's state.**
  The stats handler passed Qdrant's body to the browser without checking the
  status, and a Qdrant error is valid JSON — so a missing collection, a wrong
  api-key or a typo in `QDRANT__COLLECTION` reached the admin panel as a
  reply with no statistics in it, and a full collection looked empty. It is
  now a failure, and the status and body go to the log where the rest of the
  codebase puts a 5xx's detail.

- **A backup archive is now known to be complete, when it is written and
  when it is read.** `pack_tar_gz` finalised the tar but left the gzip stream
  to `Drop`, where flate2 discards the result: a volume that filled during the
  last few kilobytes produced a truncated archive that still decompressed to a
  plausible tar prefix, and the run reported success. The finalisation is now
  awaited and the bytes flushed. Reading one back had the matching gap — the
  tar end-of-archive marker is not the end of the gzip stream, so the CRC
  trailer was never consulted and a truncated archive restored as though it
  were whole. Both sides now check, and a test reads back what it just wrote.

- **A restore connection that could not be put back is now closed instead of
  pooled.** The three statements that reset it discarded their errors. If the
  rollback failed — the same `SQLITE_BUSY` or `SQLITE_FULL` that made the copy
  fail — the write transaction stayed open, the detach could not succeed while
  one was, and turning foreign keys back on is a silent no-op inside a
  transaction. The connection then went back to the pool holding the write lock
  with foreign-key enforcement off, which is precisely what those statements
  exist to prevent, and every later user of it inherited both with nothing to
  show why. Each step is now checked, and a connection that could not be reset
  is closed so the pool discards it.

- **A backup run is serialized as a whole, not only its retention pass.**
  The lock was taken inside the pass, so it protected list-and-delete against
  another pass but not against the window between a run's write and its own
  pass. A competing run could take the fresh archive in that window, leaving
  the first run returning a path to a file that had just been deleted — the
  admin answering `ok: true` for a backup that is not there. The lock is now
  taken before the archive is written and the guard handed to the pass, so
  list-and-delete can never overlap another run's write.

- **A backup no longer leaves its snapshot behind on the Qdrant host.**
  Qdrant keeps a copy of every snapshot it creates, and nothing here deleted
  it — the retention quota prunes local archives only, and the only snapshot
  endpoints this code used were the request and the download. So every daily
  backup added a collection-sized snapshot to the Qdrant host, growing
  without bound until that volume filled; and then the snapshot request began
  failing, which aborts the very backup that exists to protect against exactly
  that. Our copy is now verified and the host's is dropped, in that order, so
  a failed verification still leaves the server-side copy for a retry. A
  delete that fails, for whatever reason, is logged and does not fail the
  backup.

- **A Qdrant that refuses a snapshot now says so.** Neither the snapshot
  request nor its download checked the HTTP status, so a 404 for a missing
  collection, a 401 for a wrong api-key or a 500 had its body handed straight
  to the JSON parser, which rejected it — leaving `error decoding response
  body: missing field 'result'` as the only account of a failed backup, with
  the status nowhere in it. The status is now checked before the body is
  parsed, as the restore path in the same file already did.

- **A backup works from a directory whose path contains an apostrophe.**
  `VACUUM INTO` takes a string literal and SQLite has no backslash escape, so
  an unescaped `'` in the path ended the literal there and the statement
  failed. Every backup — the 02:00 one and the admin button alike — was
  therefore impossible from a directory like `C:\Users\O'Neill\…` or an
  iCloud/OneDrive folder with a quote in it, with nothing in the message
  saying why. The path is now escaped exactly as the restore path already
  was.

- **Verification no longer reads a file outside the archive.** The manifest
  inside a backup names its members, and those names were joined onto the
  unpacked directory without checking what they were — an absolute path makes
  `join` throw the base away. A hand-delivered archive could therefore have
  the restore hash, and report on, any file the service can open; the digest
  appears in the mismatch message. The name is now held to being a plain file
  name wherever it is first consumed, the same rule the restore already
  applied to the same two names, and the rule is stated once and tested once.

- **A failed backup no longer leaves its work directory on the backup
  volume.** The directory holding the fresh database copy — and, when Qdrant
  answered, its snapshot too — was removed only on the success path, so six of
  the seven ways a run can fail abandoned a full copy of the database there.
  Nothing reclaimed it: the backup listing only shows `*.tar.gz`, and retention
  only deletes what the listing returned, so a leftover stayed outside the
  quota indefinitely. On a volume filling up because of the leak, the failures
  then fed themselves. The directory is now owned by a guard that removes it on
  every exit, successful or not, and a pack that fails part-way also removes its
  half-written archive, which the listing would otherwise have offered for
  restore.

- **A misspelt `--bench` no longer starts the server instead.** With no
  path after the flag, `parse_args` returns `None` and the run fell through
  to the normal startup: the benchmark quietly became a full server, with a
  database, a listener on port 8000 and the frontend — and no report, and
  nothing in the log to explain its absence. A flag in the path position
  (`--bench --bench-query "q"`) was taken for a file to benchmark, so a
  typo sent the engine looking for a document named `--bench-query`. Both
  now say what is missing and stop, before anything is provisioned. A
  `--bench` with a real path is unaffected.

- **The check that the committed bundle matches the source now sees added
  files.** It compared with `git diff`, which reports nothing for an untracked
  file, so a `frontend/dist` that gained an asset without losing one passed
  with a bundle no build produces. It now stages the directory and compares
  the index.

- **A document row that was not written is no longer reported as written.**
  The insert used `INSERT OR IGNORE`, but the id is a fresh UUID per upload and
  is the table's only unique column, so there was nothing for it to ignore: it
  could only mask the one failure that must not be masked. An ignored insert
  returns success, the upload is reported as done, and its vectors are already
  in Qdrant — leaving an orphan with no row for the delete path to reach.
  Uploading the same file twice is unaffected: only the id is unique.

- **A generation that fails mid-stream is no longer stored as a
  complete answer.** eullm reports a failure part-way through by writing an
  `error` object on its own line of the NDJSON stream, which is not a chunk
  and so did not parse. It was skipped like any other unrecognised line,
  which ended the stream *cleanly* — and a cleanly-ended stream is persisted
  as the model's reply, so a context-length overflow or an OOM halfway
  through left the user with a silently truncated answer that came back as
  authoritative on every later reload, and was replayed into the prompt as
  history. Such a line now ends the stream the way a severed connection
  does, so the partial text is shown but not saved. Lines that are not a
  recognised error are still skipped, so a newer eullm cannot cut a good
  answer short.

- **A source citation can be opened again.** The filename under an answer
  was a plain link to the download endpoint, and a link click sends no
  `Authorization` header — while the API authenticates on
  `Authorization: Bearer` only, with no session cookie to fall back on. So
  clicking the document an answer came from navigated to the endpoint, got a
  401, and handed the user a JSON error body named after the file. Citations
  now fetch the original with the token and save it, under the name the
  server stored.

- **Logging out no longer leaves the next login with a disabled
  interface.** The "something is running" flags belonged to the request, not
  to the session, and only that request's own cleanup cleared them. Signing
  out during an answer left the question box and the send button disabled
  until the abandoned stream ended — up to its ten-minute abort — and
  signing out during an upload left the file picker disabled for as long as
  the upload ran, with the previous session's "Processing (OCR → Chunking →
  Embedding)" banner still on screen. Those flags are now cleared on logout,
  and a stream that no longer owns the view stops writing to it instead of
  appending into whatever the next session is looking at.

- **A partial answer survives a dropped connection.** When the SSE stream
  died after tokens had already arrived — a proxy reset, a laptop lid
  closing, the abort that ends a very long generation — the frontend threw
  the streamed text away and replaced it with `Error: ...`, so a long
  answer the user had just watched arrive vanished, and because the
  backend never persists a severed answer, a reload could not bring it
  back. The text is now kept and the failure appended after it, which is
  what the backend's own `{ error }` event already did.

- **Switching conversation mid-answer no longer writes into the wrong
  thread.** The conversation list stays clickable while a reply streams in,
  and every arriving token was appended to the last message on screen. So
  leaving a conversation mid-answer spliced the rest of the answer into
  the one opened instead, and coming back before it finished appended it
  to the question itself, since the reloaded list has the question but not
  yet the answer. The stream now stops writing to the screen as soon as the
  conversation changes; if you are back on it when the answer is complete,
  the conversation is reloaded with the full answer. First reported, and
  fixed for the switch away, in #86.

- **A conversation title is never cut in half a character.** The automatic
  title truncated with `substring(0, 50)`, which counts UTF-16 code units, so
  a question containing a character outside the basic plane — an emoji, rarer
  CJK, some Indic conjuncts, two units each — was cut between the halves at
  position 49 or 50, and the stored title carried a lone surrogate that every
  renderer draws as `�`. The cut is now on a code point.

- **A retrieved chunk is no longer rewritten by the prompt template.** The
  prompt was assembled with a chain of `str::replace` calls, each scanning
  what the previous one had produced. Any chunk or stored message containing
  the literal text `{question}` or `{context}` — a template guide, a config
  file, a document *about* this project — had that token replaced by the
  user's question, inside the evidence the model was shown. The evidence
  stopped being what the document says, and the text the user asked about
  appeared in the middle of it. Substitution now happens in a single pass
  over the template, so an inserted value is never scanned again. The prompt
  is byte-for-byte what it was for any document that does not contain the
  tokens.

- **A restore applies the members the archive's manifest names, and
  refuses an archive of another collection.** Verification and restore
  disagreed about where the members are: the manifest was hashed under the
  names it gives, then the files were looked for under names rebuilt from the
  current configuration. Rename `QDRANT__COLLECTION`, or move an archive to
  another installation, and the snapshot was verified and then never found —
  the run reported success and only the database came back. The two now agree
  by construction, and an archive whose manifest names a different collection
  is refused before anything is written rather than uploaded into the wrong
  one. A restore that finds no database at all is an error, not a successful
  restore of nothing, and it is refused before the snapshot is uploaded rather
  than after; the collection name was already in every manifest and was read
  by nothing.

- **An upload that cannot record its metadata does not leave its vectors
  behind.** Ingestion wrote the chunks to Qdrant first and the SQLite row
  second, with nothing between them: a failing insert left a document whose
  vectors were still retrieved by every query and still quoted as a source
  pointing at an id that resolves to nothing, while the document list — read
  from SQLite — never showed it. So there was no id to delete them by and no
  way to reach them again short of rebuilding the collection. The vectors are
  now removed again when the insert fails, which is the same invariant
  `purge_document` already states for the delete path — and when the Qdrant
  write itself fails part-way, which on a document of more than 1000 chunks
  left the batches already written behind in the same way.

### Security

- **`axios` 1.20.0 in the web interface.** The bundled 1.18.1 fell under
  twelve advisories fixed in 1.20.0. Most concern Node's HTTP adapters,
  which a browser bundle never loads; the rest are prototype-pollution
  gadgets and header injection through inherited properties, reachable only
  together with a pollution bug elsewhere in the page. `frontend/dist` is
  rebuilt with it. The build tooling is refreshed within its ranges as well
  (`postcss` 8.5.28, `browserslist` 4.29.3, `nanoid` 3.3.19). `vite` 4 and
  its `esbuild` stay: their advisories concern the development server, and
  the fix is the major upgrade to `vite` 8, which deserves a change of its
  own.

- **`event-listener` 5.4.2, for RUSTSEC-2026-0221.** 5.4.1 let a
  `!Send` tag cross threads through its stack-allocated listener: a data
  race in safe code. It reaches this server through sqlx, which uses
  neither tags nor that listener, so nothing here could trigger it; the
  bump clears the warning `cargo audit` raised. It also drops
  `concurrent-queue` from the lockfile.

---

## [0.1.46] - 2026-09-25

### Added

- **Backups can now prune old archives.** New `BACKUP__RETAIN_LAST`:
  after each successful backup, archives beyond that many newest are
  removed, oldest first. `0` (the default) disables pruning and keeps
  the historical accumulate-forever behaviour — daily backups no
  longer fill the disk unnoticed. Pruning only ever touches `backup_*`
  names, never the archive the run has just written, and only warns on
  failure, never failing the backup itself.

- **`.doc` files are read — Word 6.0 through 2003.** The upload dialog
  accepted them, but every real one failed: `.doc` went to the `.docx`
  reader, which only understands the ZIP-based format. The binary
  format is now read directly, with no external converter — body,
  footnotes, headers and tables, the visible text of links and other
  fields, Unicode, and for Word 6.0/95, which predates Unicode, the code
  page named by the document's fonts. A file is read by what it
  contains, so a `.docx` renamed to `.doc` still works. Password-protected
  documents and those older than Word 6.0 are refused with a message
  saying so.

- **PowerPoint presentations are read — `.pptx` and `.ppt`.** Slides
  come in the order the presentation shows them, not the order their
  parts were saved in, each followed by the text of its SmartArt
  diagrams and its speaker notes; a table stays one row per line. The
  PowerPoint 97–2003 binary format is read directly, following
  PowerPoint's own record of its last save, so text deleted in an
  earlier session does not come back. Either kind is recognised by its
  content, so one renamed to the other still works.

- **OpenDocument text and presentations are read — `.odt`, `.odp`.**
  LibreOffice's own formats. Text deleted under change tracking and
  reviewers' comments are left out; a presentation's speaker notes are
  kept. Password-protected files are refused with a message saying so.

- **RTF documents are read, and so are `.doc` files that are really
  RTF,** as Word writes them when asked to — until now such a `.doc`
  was refused as "not supported yet". Any code page and Unicode, tables,
  text boxes, headers and footers, and the visible result of links and
  other fields; comments, hidden text, pictures and embedded objects
  are skipped.

- **EPUB e-books are read,** chapter by chapter in reading order,
  without the table of contents. A book under DRM is refused with a
  message saying so rather than indexed as noise.

- **E-mails are read — `.eml` and Outlook's `.msg` — attachments
  included.** Subject, sender, recipients, date and attachment names,
  then the body — the plain-text one, or the HTML one, or Outlook's
  compressed RTF when that is all there is — then each attached document
  (PDF, Word, Excel, PowerPoint, OpenDocument, RTF, EPUB, text, another
  e-mail), read as it would be if uploaded on its own, then any message
  forwarded as an attachment. Pictures are listed but not read: in
  e-mail they are mostly logos and signatures. An attachment that cannot
  be read is skipped, not the message. What one upload's messages may
  have read — attachments and the text they expand to, nested messages,
  a compressed RTF body once decompressed — is capped at 512 MiB, as
  ZIP-based documents are. Messages saved in a legacy 8-bit code page
  decode the way Outlook wrote them.

- **Pictures are read through OCR — `.png`, `.jpg`/`.jpeg`,
  `.tif`/`.tiff`, `.bmp`, `.gif`, `.webp`.** The same Tesseract, in
  Italian and English, as scanned PDFs. Every page of a multi-page TIFF
  is read, fax compression included, and cited by page like a PDF's; a
  transparent background is laid over white, so dark text on it is not
  read as black on black.

- **`.xlsm`, `.xlsb` and `.ods` spreadsheets are read.** The reader
  behind `.xlsx` already understood them; they were simply not accepted.
  Macros in an `.xlsm` are never run — only cell values are read.

- **`.env.example` is now checked against the settings the loader
  reads.** A test keeps the template and a list of every
  `SECTION__FIELD` key in step, in both directions: a key the template
  assigns but the loader does not know — a typo, or a setting since
  removed — fails the build, and so does a listed setting missing from
  the template. It matters because unknown variables are ignored
  silently, so a misspelled one looked configured while doing nothing.
  The list is kept by hand next to the settings: a new setting still
  has to be added to it to be covered.

- **Regression coverage for four untested pure helpers.**
  `expand_tilde` (data-dir resolution), `fmt_bytes`/`fmt_eta`
  (bootstrap progress output) and `is_bad_request` (the 400-vs-500
  split on restore failures) were deterministic and load-bearing but
  had zero tests. Covered now, boundaries included. `l2_normalize`
  was deliberately left out: it is dead code, and testing it would
  cement it instead of questioning it.

### Changed

- **The benchmark report and its logs are fully English.**
  Completes the translation pass: section headers, table labels,
  mermaid slices, console lines and tracing messages that were still
  Italian now match the rest of the report. Comments, output and log
  strings only; no behavioral change.

- **The application's last Italian text is now English.** In the web
  UI: the admin panel's Qdrant and SQLite tabs, the chat's error and
  timeout messages, the source list and the ingestion banner — and the
  dates in that panel now follow the browser's locale instead of being
  forced to Italian. In the server: the first-install banner that
  prints the generated admin password, the `embedding_device` value
  `/api/info` reports when the embedding lock is poisoned, the warning
  logged when a CUDA embedding batch runs out of memory, and the doc
  comments and log lines left over from earlier passes. Italian that is
  there on purpose stays: the heading keywords the chunker matches in
  Italian documents (`articolo`, `capitolo`, …), the multilingual
  example inside the answer prompt, and Italian test fixtures.

- **HTML pages keep all their visible text.** Text outside paragraphs,
  headings, list items and table cells — in a `div`, a `blockquote`, a
  `pre`, after a `<br>` — was dropped, and a list item holding a
  paragraph was indexed twice. Every visible piece of text is now kept
  once, in order, with a table row on one line; what a browser never
  shows — scripts, styles, the page's `head` — still is not. The same
  reader handles the chapters of an EPUB and the HTML body of an
  e-mail. Since an unchanged `.html` file now extracts differently,
  `EXTRACTION_CONFIG_VERSION` is 2: chunks ingested from now on carry
  `pv2` in their provenance id.

- **The chat history no longer stores a copy of every source's text.**
  Each answer was saved together with the full text of every chunk it was
  built from — up to 15 of them, 10–15 KB per question, kept for good —
  although nothing ever displayed it: the web UI shows a source's file,
  pages and score. Stored sources now keep only what locates the passage
  (document, chunk, byte range, pages), so each question takes about a
  quarter of the space. The live answer still carries the chunk text.
  Messages already in the history are left as they are; for new ones,
  `GET /api/chat/history` returns sources without `text`.

### Fixed

- **Two backups started in the same second no longer overwrite each
  other.** Archive and work-dir names had one-second granularity, so a
  double-clicked "Run Backup Now" (or a manual run landing on the cron
  tick) silently replaced the first archive with the second. Names now
  carry a short random suffix after the timestamp prefix the listing
  sorts on.

- **`--bench-live` reports every ingestion stage again.** Since 0.1.25
  the live report showed 0 ms for text extraction and Qdrant upsert on
  every real upload: a translation pass renamed the stage names the
  report looks up, but not the names the upload handler records them
  under, and the lookup fell back to zero without a word. Each row's
  columns no longer added up to its own total, the averages understated
  the real time, and neither stage could ever be named the bottleneck.
  Stages are now an enum, so the two sides cannot disagree again.

- **The `top_k` request field is honored instead of silently ignored.**
  `POST /api/query` accepted `top_k` but always retrieved the
  hardcoded 15. A value sent by an API client is now used, clamped to
  `1..=50` so nothing fans out to Qdrant unbounded; absent still means
  15. The web UI used to send `top_k: 5`, which the backend ignored —
  it no longer sends it, so its answers keep the depth of 15 they have
  always had instead of dropping to a third of their context.

- **Downloads stream instead of buffering the whole file in RAM.**
  `GET /api/documents/{id}/download` loaded the entire original (up to
  the 1024 MB cap) before responding — the same peak the upload path
  just stopped paying. The file now streams with a `Content-Length`
  header; headers and 404 behavior are unchanged. A read failing
  mid-stream truncates rather than 404s, inherent to streaming.

- **An unknown role in the database now logs instead of silently
  demoting.** `UserRow::role()` fell back to `User` on any unparsable
  value, and the role is re-read from the row on login and on every
  request — so a typo or a corrupt row could demote anyone, admin
  included, with nothing in the log saying why. Still fail-closed
  toward the least privilege, now with a warning naming the user and
  the offending value.

- **The upload dialog offers exactly what the server reads.** The file
  picker's allow-list had drifted from `SUPPORTED_EXTENSIONS`: `.pptx`
  was offered but refused after selection, while `.md` and `.csv` parsed
  fine but were undiscoverable. The two lists now match — the formats
  added above included — and a test keeps them matching.

- **Legacy `.xls` spreadsheets upload again.** Since 0.1.41 every
  Excel 97–2003 workbook was refused with "xlsx is not a readable zip
  archive": the check against decompression bombs — which only ZIP
  containers can be — ran on every spreadsheet, and a real `.xls` is
  not a ZIP. It now runs only when the file actually is one, judged by
  its content rather than its name, so an `.xlsx` renamed to `.xls` is
  still inspected.

- **A file that crashes its reader is refused cleanly.** When a
  document reader panicked on an upload — calamine, the spreadsheet
  library, does on some `.xlsb` files — the upload answered 500 "parse
  task panicked". It now gets the usual 422 saying the file could not be
  read, and `--bench` no longer crashes on such a file.

- **A password-protected `.docx`, `.xlsx` or `.pptx` says so.** Office
  encrypts such a file into an OLE container instead of a ZIP archive,
  and it was refused as "not a readable zip archive". The message now
  says the document is password-protected.

- **OCR can no longer crash the server after it finishes.** Tesseract
  was loaded for each scanned document and unloaded after it. The one
  bundled here is built without OpenMP, but the Tesseract of a Linux
  distribution — used when `TESSERACT_DYNAMIC_LIB_PATH` points to it, or
  when the bundled one is missing — is not: unloading it from under its
  worker threads crashed the process with SIGSEGV, now and then. It is
  now loaded once and kept.

- **Form inputs now match the server-side limits.** The question box
  had no cap while over-4000-character questions get a 400, and the
  new-password fields stopped at a 6 minimum while over-128-character
  passwords get a 400. Both now stop at the boundary (`maxLength`),
  with the password hint stating the real 6-128 range.

- **BUILD.md no longer shows a stale database default and documents
  `DATA__DIR` for source builds.** The runtime table listed
  `DATABASE__URL=sqlite://rag_users.db`, but the default has long been
  `{DATA__DIR}/db/rag_users.db` — and nothing told a `cargo run`
  developer that the data root defaults to `target/debug/`. Both fixed
  where a source builder actually reads them.

### Security

- **rustls 0.23.45, for RUSTSEC-2026-0285.** The rustls in use, 0.23.41,
  accepted TLS 1.3 handshake messages across encryption-level boundaries
  (medium severity). It secures the binary's outgoing HTTPS — reqwest,
  so the downloads at first run and the Qdrant client among them — and
  sqlx's Postgres connections. Only rustls and rustls-webpki moved in
  `Cargo.lock`; `cargo audit` reports no vulnerability.

---

## [0.1.45] - 2026-09-17

### Fixed

- **Conversation titles are capped at 200 characters.** `PUT
  /api/conversations/{id}` only rejected empty titles, so anything up
  to the 2 MB JSON body limit was stored verbatim and returned on
  every list call — while the UI only ever shows ~50 characters. Now
  enforced up front via a tested `validate_title`, mirroring
  `validate_query` (characters, not bytes).

- **Startup now refuses a misconfigured eullm context sizing.**
  `EULLM__NUM_CTX * EULLM__BATCH_SIZE` becomes `--ctx-size`, but neither
  side was validated: `0` started eullm with no context or no slot, and
  an absurd pair overflowed `u32` — panicking in debug, wrapping in
  release into a garbage context a RAG prompt will not fit in. Both are
  rejected fail-fast in `Settings::load`, following the existing
  `validate_auth`/`validate_storage` pattern.

---

## [0.1.44] - 2026-09-16

### Fixed

- **A `ChunkEnricher` returning the wrong number of texts no longer
  panics the upload.** The trait promises one `String` per chunk but
  nothing enforced it, and both ingestion paths indexed the texts by
  chunk position — a short or long return from any registered enricher
  panicked inside the live request task (after pointlessly embedding
  the wrong-sized batch first). Both call sites now check the
  contract up front via `extensions::ingestion::ensure_enriched_len`,
  mirroring the existing embeddings/payloads length bail.

- **A failed SQLite restore no longer poisons its pooled connection.**
  `copy_tables` runs inside `BEGIN IMMEDIATE`, but on a mid-copy failure
  the error returned before `COMMIT` with no `ROLLBACK`: the connection
  went back to the pool holding an open write transaction, so the next
  operation on it — including a retried restore, which cannot `BEGIN`
  inside it — failed far from the actual cause. The half-written copy is
  now rolled back first (live rows survive a failed restore), alongside
  the existing detach/foreign-keys cleanup.


- **`IngestionGuard::start` returns an error instead of panicking on a
  closed semaphore.** The `acquire_owned().expect(...)` sat at the top of
  every upload request: unreachable in practice, but a panic there would
  take down the request task rather than surfacing a normal 500 — against
  this file's own rule that request-path failures are `Result`s. The
  upload handler maps it to a bare 500 (detail in the log, per the 5xx
  rule), and a new test pins the no-panic behaviour.

---

## [0.1.43] - 2026-09-14

### Performance

- **The upload and backup handlers no longer block the async executor on
  disk I/O.** Saving the original file copied it with `std::fs::copy`
  straight inside the handler, which stalls every other request sharing
  that worker thread for as long as the copy takes — up to the whole
  configured upload limit. Listing backups did the same with a
  synchronous `read_dir`. Both use `tokio::fs` now, as do the cleanup
  paths around them. The one exception is the staging file's `Drop`
  guard, which cannot await: an unlink is a syscall rather than a
  transfer, which is the part that actually mattered.
- **Uploads stream to disk instead of being buffered in RAM.**
  `process_upload` used to load the entire body into a `Vec<u8>` (plus
  a transient copy) before hashing and writing it, so a few concurrent
  large uploads could OOM the process — on ARM boards fatally. The
  multipart field is now written to the temp file chunk by chunk, the
  sha256 for the provenance chain is computed incrementally (identical
  digest to a one-shot hash), and the request is rejected with `413` as
  soon as the configured `STORAGE__MAX_UPLOAD_MB` cap is exceeded rather
  than after the whole body arrived. The `DefaultBodyLimit` stays as a
  backstop; the parser interface is unchanged, and a partial temp file is
  removed on every error path.

### Fixed

- **Restore refuses non-regular tar entries, not just escaping paths.**
  `unpack_tar_gz` checked each entry's path against traversal but never
  its type: a symlink or hard link with an innocent path still
  materialised an arbitrary target on unpack, and a restored symlink
  could redirect a later write outside the destination. Only regular
  files and directories are now unpacked — everything this project's
  own archives ever contain.

### Security

- **Uploads are staged owner-only, under the data directory, and only
  after the format is accepted.** Three things about the file an upload
  is written to while it is parsed. It was created with the default
  `0644`, so on a shared host every other local user could read whatever
  was being ingested for as long as the parse took; it is now `0600` on
  Unix. It lived in the system temp directory, which on most Linux
  installs is a tmpfs — that is RAM, so a large upload went straight back
  into the memory that streaming to disk exists to avoid, and on a small
  ARM board could fill it; staging now lives in `{DATA__DIR}/tmp`, which
  is also on the same filesystem as the originals store. And the
  extension was checked only by the parser, at step 2 — a `.pptx` was
  written out in full, up to the configured limit, and only then
  refused; an unsupported format is now a `415` before a single byte is
  written.

  Because staging left the system temp directory it also left the
  operating system's cleanup of it, so the startup sequence now sweeps
  `{DATA__DIR}/tmp` — safe there and only there, since no upload can be
  in flight before the server accepts requests, and every file present is
  by definition left over from a process that died mid-upload.

---

## [0.1.42] - 2026-09-14

### Changed

- **A search result whose payload cannot be read is now logged instead of
  silently dropped.** Points written by an older schema, or by another tool
  against the same collection, were discarded by `.ok()?` with no trace —
  which is what made "the answer ignores a document I know is in there"
  impossible to explain from the outside. Each dropped point is logged with
  its id and the parse error, plus a summary line when a search loses any.

### Performance

- **Two uploads at once no longer sabotage each other.** The ingestion
  window — unload eullm, move bge-m3 onto the GPU, parse/chunk/embed, move
  it back, reload eullm — was only counted, never serialised: the first
  upload to finish reloaded the chat model into VRAM while the second was
  still embedding in it, and the second hit CUDA OOM, fell back to the CPU
  and finished an order of magnitude slower without reporting anything to
  anyone. One permit now guards the window, so the second upload waits its
  turn; the pair takes about as long as before and neither degrades.

- **Qdrant now carries a payload index on `document_id`.** Without one,
  every `document_id` filter — which is every document deletion — was
  answered by reading the payload of every point in the collection: at ten
  thousand documents, removing one meant scanning millions of points to
  find its few hundred. The index is created on startup for existing
  collections too, not only for newly created ones, and a Qdrant that
  refuses it logs a warning rather than blocking startup.

- **The chunker no longer shifts its whole overlap window on every
  removal.** `Vec::remove(0)` moved every remaining element down a slot
  each time; with the `" "` separator the window holds 150–200 words and
  most of them are dropped at each flush, so a 10 MB document spent a few
  hundred million element moves achieving nothing. It is a `VecDeque` now,
  and each piece carries the character count taken when it went in instead
  of being counted a second time on the way out.

### Fixed

- **Startup now refuses a misconfigured `STORAGE__MAX_UPLOAD_MB`.** `0`
  used to turn into `DefaultBodyLimit::max(0)` and reject every upload
  with a misleading `413`; values above the new provisional ceiling of
  `1024`, and values whose byte count overflows `u64`, are rejected too —
  all fail fast in `Settings::load`, following the existing
  `validate_auth` pattern. The ceiling is deliberately provisional:
  while upload bodies are buffered in RAM it doubles as memory
  protection, and it can rise once uploads stream to disk.

- **A long answer is no longer truncated and then saved as if it were
  complete.** The HTTP client applied a single 180-second timeout to every
  request, and in `reqwest` that timeout covers the whole request including
  the response body — so on the streaming endpoint it was not a liveness
  check but a cap on how long the model was allowed to talk. With
  `EULLM__NUM_PREDICT=4096` a 14B model passes three minutes routinely.
  Past that the connection was dropped mid-sentence, and because a severed
  stream reached the SSE layer as the same closed channel a finished one
  does, the half-written text was stored as the assistant's reply, shown
  with a normal completion event, and — with `use_history` on — replayed to
  the model on every later turn in the same conversation. The streaming
  path now bounds *silence* rather than total duration: 30 s to open the
  connection and 180 s without a single byte from eullm, which still covers
  the legitimately long gaps (a cold model load, or the swap back into VRAM
  after `EULLM__UNLOAD_DURING_INGESTION` or an eullm-mode embedding call)
  while letting a healthy generation run to its end. An interrupted
  generation is now reported as such: the stream emits an `error` event
  instead of `done`, the partial text is deliberately not persisted, and
  the UI marks what did arrive as incomplete. Unary requests (`invoke`,
  `unload`, `embed`) keep the 180-second total timeout, which is the right
  shape for them.

### Security

- **A `conversation_id` from the request body is now checked against the
  caller before it is used.** Every read in `db::conversations` filters by
  `user_id` as well, so a conversation id belonging to someone else could
  never disclose anything — but the write paths took the id at face value,
  which let a user file their own messages under another user's
  conversation and, through the `updated_at` touch that follows every
  insert, move that conversation to the top of its owner's list. Both
  `/api/query` and `/api/query/stream` now answer `404 conversation not
  found` for an id the caller does not own (404 and not 403: whether
  someone else's conversation exists is not theirs to learn), and
  `touch_conversation` carries a `user_id` filter of its own.

- **Stale-instance cleanup at startup no longer matches on command lines.**
  Before spawning eullm the supervisor ran `pkill -f <path to eullm>`,
  which tests that path as an extended regex against the full command line
  of every process the user owns — an editor with the file open, a
  `tail -f` on it, a script that merely names it, all matched and all
  killed — and, since the path was never escaped, a data directory
  containing `+` or `(` silently changed what it matched. On Linux it now
  reads `/proc/<pid>/exe`, the kernel's own answer to what a process is
  running, and signals only the processes that are genuinely this binary
  (including one left over from an in-place upgrade, which the kernel
  reports with a " (deleted)" suffix).

---

## [0.1.41] - 2026-09-14

### Changed

- **The server now listens on `127.0.0.1` by default instead of
  `0.0.0.0`.** This binary serves its admin UI over plain HTTP and
  terminates no TLS anywhere, so the previous default put the login
  password and every session token on the wire in clear text, readable by
  anyone on the same network — while the quick start told the user the app
  lives at `localhost`. It is now reachable only from the machine it runs
  on unless `SERVER__HOST` says otherwise, and when it does say otherwise
  the server logs a warning at startup explaining what that costs. See
  "Reaching it from another machine" in the README for the reverse-proxy
  setup this replaces it with.

  **Upgrading:** an installation that was being reached from other
  machines will stop answering them until `SERVER__HOST=0.0.0.0` is set
  explicitly — preferably behind a proxy that terminates TLS.

### Removed

- **Five declared dependencies that no code referenced** — `quick-xml`,
  `validator`, `pulldown-cmark`, `walkdir` and `zstd`. Beyond build time,
  two of them were pulling known-vulnerable crates into the tree for
  nothing: dropping `validator` removes `idna 0.5.0` (RUSTSEC-2024-0421)
  entirely, and dropping the direct `quick-xml` removes one of the four
  copies flagged by RUSTSEC-2026-0194/0195.

### Fixed

- **Downloaded filenames are sanitised for the `Content-Disposition`
  header.** The stored filename comes verbatim from the multipart body
  while `storage::path_for` only neutralises path traversal, so a name
  containing `"`, `\` or CR/LF reached the header uninterpolated —
  breaking out of the quoted string at best, response splitting at
  worst. Quotes, backslashes and ASCII controls now become `_`;
  legitimate names (including non-ASCII ones) are untouched.

- **The user-management stubs no longer answer non-admin callers.**
  `GET /api/auth/users` returned `200` to any authenticated role, and the
  other stubs had no role check at all — whatever gets built on them later
  would have inherited the hole. All four now require the admin role
  (`403` otherwise), mirroring `api::admin::require_admin`, via the
  previously-dead `Role::can_manage_users` helper.


- **A single malformed SSE line no longer discards a whole streaming
  answer.** `JSON.parse` on a `data:` line ran unguarded inside the
  stream loop, so one truncated chunk (flaky network) threw into the
  outer `catch` and replaced the partial answer with a generic error.
  Malformed lines are now skipped, keeping the tokens received so far.
  The upload progress bar is also guarded against a missing
  `evt.total` (chunked encoding), which previously rendered as `NaN%`.

- **`POST /api/auth/change-password` now enforces a password policy
  instead of accepting anything.** An empty (or up to 5-character) new
  password was hashed and stored without complaint via a direct API call —
  the 6-character floor only existed in the frontend form — and there was
  no upper bound at all, so a megabyte-long password fed straight into
  Argon2. The endpoint now rejects passwords shorter than 6 or longer
  than 128 characters with a 400, enforced by a tested
  `auth::password::validate_new_password`.

### Security

- **A published placeholder is no longer accepted as `AUTH__JWT_SECRET`.**
  The `.env.example` shipped in every release tarball carried
  `change-this-to-a-long-random-string` uncommented — 35 characters, so it
  cleared the 32-character rule added in 0.1.40 and the server started
  normally. An operator who copied the template, which is what the template
  tells them to do, was signing session tokens with a key published on
  GitHub: anyone could forge a token for user 1, the seeded administrator,
  and the database re-check added in this same release would then look that
  row up and hand back its real admin role.

  Startup now refuses every value this project has ever printed in a
  template or a document, whatever its length, and the shipped template
  ships empty.

  **Upgrading:** an installation still running on the template value will
  refuse to start until a real secret is set (`openssl rand -hex 32`). That
  is deliberate — it was forgeable — but check `.env` before rolling this
  out. Replacing the secret logs everyone out; if it was the placeholder,
  that is the point.

- **A question now has a maximum length, and the embedder truncates
  regardless.** The only limit was axum's 2 MB default body: a question
  that size was tokenised whole, embedded on the CPU, and pasted into the
  prompt, so any authenticated account — including a plain `user`, who
  cannot upload anything — could spend minutes of CPU and gigabytes of
  memory per request, repeatedly. Questions over 4000 characters are now
  refused with a 400 before any of that happens, and the tokenizer is
  configured with bge-m3's own 8192-position limit at load time, so the
  bound holds for every caller rather than only this one endpoint.

- **DOCX and XLSX are refused when they declare more than 512 MiB
  uncompressed.** Both formats are zip archives that the parsers inflate
  into memory in one go, and the upload limit only ever bounded the
  *compressed* file — a thousand-to-one ratio is trivial, so a few
  kilobytes on the wire could become gigabytes of resident memory, fatal on
  the ARM64 boards this project ships builds for. The check reads the
  archive's central directory only, so nothing is decompressed to run it.
  It stops the ordinary bomb, which declares its real size; an archive that
  lies about its sizes needs the decompression itself to run through a
  capped reader, and that is left for its own change.

- **A token's claims are now re-checked against the database on every
  request.** The role and identity were taken from the JWT and believed as
  written, so deactivating a user, demoting an administrator, or changing a
  leaked password had *no effect* until the token expired on its own —
  eight hours, by default. The role is now read from the row, and the
  lookup already filters `is_active = 1`, so a deactivated account stops
  working on its next request. Costs one SQLite primary-key lookup per
  authenticated request. Tokens issued before a password change still
  survive until expiry; closing that needs a token-version column and is
  left for its own change.

- **`AUTH__ADMIN_DEFAULT_PASSWORD` no longer overwrites an existing admin
  password on every start.** It rewrote the stored hash at *every* startup,
  which meant an installation carrying that variable could never really
  change its admin password — the value in `.env` silently won again at the
  next restart, even after the admin had set a new one from the UI. And
  because the only check was "not empty", `=x` produced a one-character
  administrator, reinstated at every boot. It now seeds a fresh install
  only, is validated against the ordinary password policy, and is ignored
  with a warning once the account exists.

  **Upgrading:** if you relied on that variable to reset the password, use
  the new `AUTH__ADMIN_RESET_PASSWORD` — it does the same thing on purpose,
  says so loudly in the log, and should be unset again afterwards.

- **The API no longer answers cross-origin requests from anywhere.** It
  attached `CorsLayer::permissive()` — `Access-Control-Allow-Origin: *`
  with every method and header — to a binary that serves its own frontend
  from its own origin, so the layer permitted everything and protected
  nothing: any page on the internet could call this API from a visitor's
  browser and read the answers. There is now no CORS layer at all unless
  `SERVER__CORS_ORIGINS` names the origins to allow, which is only needed
  for a dev server on another port.

- **Every response now carries security headers.** A Content Security
  Policy (`script-src 'self'`, `frame-ancestors 'none'`), `nosniff`, and
  `Referrer-Policy: same-origin` — none of which were set, on a binary
  whose entire surface is an administrative UI. The policy admits
  `'unsafe-inline'` for styles alone, because the upload progress bar sets
  its width through a style attribute; script-src is not relaxed to buy
  that.

- **Server errors no longer hand their internals to the caller.** A 5xx
  returned the `anyhow` chain verbatim — filesystem paths, the Qdrant URL,
  SQL text, the body of an eullm reply — which is free reconnaissance for
  anyone who can provoke one. The detail now goes to the log, where it is
  useful, and the response says only that something broke. Client errors
  are unchanged: a 4xx still explains what the caller got wrong.

- **CI now runs on pull requests, and checks that the committed frontend
  bundle matches its source.** The workflow only triggered on pushes to
  `main`, so an external contributor's code was validated *after* it had
  already landed — the wrong order, and one that only worked this month
  because every such pull request was compiled and tested by hand. The
  bundle check exists for the same reason: `frontend/dist` is committed,
  so a pull request carries a minified file built on someone else's
  machine that nobody can review by reading it. CI rebuilds it and fails
  on any difference. First-time contributors from a fork still need a
  maintainer to approve the run, which is the correct default and is left
  alone.

- **Repeated failed logins against one account now earn a growing delay,
  and only a few password verifications run at once.**
  `POST /api/auth/login` accepted unlimited attempts and paid an Argon2id
  verification for each one, which made two things cheap that should not
  be: brute-forcing `admin` — an account that exists on every install,
  under a name everyone knows — and saturating the CPU that also has to
  serve the language model, without any credentials at all.

  After three free failures a username's next attempt waits one second,
  then two, four, and so on up to thirty. It is a delay and not a lockout
  on purpose: a lockout would let anyone deny an account to its owner just
  by failing against it. A successful login clears the count, and one
  account's failures never delay another's.

  Independently, at most four verifications run concurrently; anything
  past that is refused with `429` *before* hashing, so the cost of
  rejecting an attack does not scale with the attack.

  Neither mechanism reads the client's IP, deliberately — behind the
  reverse proxy this README now recommends, every request shares one
  address, and a per-IP limit would let one person's typo lock out an
  entire organisation. See the module documentation in
  `src/auth/throttle.rs` for the full reasoning.

- **`cargo audit` is clean: twelve advisories down to zero.** The remaining
  `quick-xml` copies went with `docx-rs` 0.4.22, `pdf_oxide` 0.3.77 and
  `calamine` 0.36.1, all of which now use the patched 0.41 — closing
  RUSTSEC-2026-0194 and RUSTSEC-2026-0195, the quadratic-parse and
  unbounded-allocation flaws reachable through any DOCX or XLSX a user
  uploads. `crossbeam-epoch` went to 0.9.21 (RUSTSEC-2026-0204).

  What is left is `rsa` (RUSTSEC-2023-0071, no fix published), which
  reaches the lockfile through sqlx's MySQL driver — a backend this project
  does not build, so the crate is never linked into the binary.
  `.cargo/audit.toml` records that with the reasoning, rather than leaving
  a permanent red line nobody reads. Seven "unmaintained" advisories remain
  on transitive crates; none has an action.

- **`h2` updated to 0.4.19** (RUSTSEC-2026-0258: unbounded empty DATA
  frames). It reaches this server through hyper under axum, and axum 0.7
  accepts cleartext HTTP/2 with prior knowledge, so the denial of service
  was reachable before any authentication ran. A patch bump; no code
  changed.

---

## [0.1.40] - 2026-09-11

### Changed

- **Upgrading to this release can stop an existing deployment from
  starting, and that is deliberate.** The `AUTH__JWT_SECRET` validation
  below is fail-closed: any installation currently running with a secret
  shorter than 32 characters will refuse to start until that secret is
  replaced (`openssl rand -hex 32`). Such a deployment was already
  forgeable, so refusing to start is the correct outcome — but it is a
  breaking change on upgrade, so check the secret before rolling this out
  rather than discovering it at the next restart. Note that replacing the
  secret invalidates every token in circulation: all users have to log in
  again.

### Fixed

- **Startup now rejects a weak `AUTH__JWT_SECRET` instead of signing tokens
  with it.** Any secret shorter than 32 characters (and a zero or
  overflowing `AUTH__JWT_EXPIRY_MINUTES`) fails fast in `Settings::load`
  with instructions (`openssl rand -hex 32`); previously an empty or
  single-character secret started normally, producing HS256 tokens anyone
  could brute-force and forge. `jwt::create_token` also returns an error
  instead of panicking/wrapping on an out-of-range expiry.

---

## [0.1.38] - 2026-08-22

### Fixed

- **Scrolling up to read earlier messages while a reply was still
  streaming was effectively impossible.** The auto-scroll effect ran
  unconditionally on every `messages` update — and streaming appends a
  token to `messages` many times a second — so any manual scroll up got
  yanked back to the bottom on the very next token. Now tracks whether
  the user is within 100px of the bottom (via an `onScroll` handler) and
  only auto-scrolls when they already were; sending your own message
  always scrolls, regardless of prior position.

### Changed

- **`bench::run()`'s chunk enrichment is now pluggable, via the same
  `ChunkEnricher` a real ingestion uses.** `--bench <file>` used to
  always call `chunker::inject_heading_context` directly, regardless of
  what a caller's `ExtensionRegistry` actually registered — meaning a
  launcher that registered its own enricher could never measure it, only
  the default. `run()` and the
  internal `run_ingestion()` now take a `&dyn ChunkEnricher` parameter;
  `run_with_extensions` passes `extensions.chunk_enricher.as_ref()` —
  already in scope exactly where `--bench` dispatches. This binary's own
  behavior is unchanged (`ExtensionRegistry::default()`'s enricher wraps
  the same heading-injection as before); any other launcher now gets a
  `--bench` that genuinely exercises whatever it registered, so results
  across enrichers come from the same tool. 121 tests pass, clippy stays
  clean.

- **`BRANDING.clientName`/`.version` are now build-time configurable**
  (`VITE_BRANDING_NAME`/`VITE_BRANDING_VERSION`, defaulting to this
  repo's own `'i3k RAG Engine'`/`'Community'` — building without them
  set is unchanged). The version badge — previously shown only in small
  print in the app's footer — now also appears next to the product name
  at login and in the main header. Added so a downstream build can show
  its own edition without forking this file — not proprietary logic,
  just a configurable label, same principle as `extensions::`'s generic
  hooks.

---

## [0.1.37] - 2026-08-22

### Changed

- **This crate is now also a library, not just a binary.** New
  `src/lib.rs` holds every module (now `pub mod`) and a new
  `pub async fn run()` containing the full startup sequence that used
  to live in `main()`. `src/main.rs` is now a thin launcher:
  `i3k_rag_engine::run().await`. Zero behavior change — same 113 tests
  pass, clippy stays clean, `--version` verified end-to-end through the
  new wiring. Other binaries can now depend on this crate, pinned to an
  exact commit.

- **New `extensions::` module: generic extension points another binary
  can register against.** Six traits (`ChunkEnricher`,
  `StructuredKnowledgeProvider`, `QueryPlanner`, `RetrievalStrategy`,
  `Reranker`, `EvidenceLayer`), bundled into `ExtensionRegistry` and
  threaded through `AppState`. `ExtensionRegistry::default()` — what
  this binary always uses — wraps only Community's own existing
  behavior (e.g. the chunk enricher default is the already-shipped
  heading-injection logic, proven byte-for-byte identical to calling it
  directly via a new test; the query planner default always routes
  `Semantic`, Community's one real retrieval path today) or is a
  genuine no-op where Community has no such feature yet (reranking,
  evidence, structured knowledge). `api::router` also now takes an
  optional second parameter of extra routes, merged in when present, so
  a launcher can add its own routes against the same `AppState` without
  this crate depending on its code. No proprietary logic lives here —
  see this repo's own rule on that. 115 tests pass (two new), clippy
  stays clean.

- **New `build_info() -> (&str, &str)`, exposing the version/commit
  `--version` already printed.** No behavior change for this binary —
  it's the same two values, now also reachable as a function. Added so
  a binary that links this crate as a pinned Git dependency can report
  the core's version/commit in its own `--version` output, without
  re-deriving it. 116 tests pass (one new), clippy stays clean.

- **New `ChunkPayload.retrieval_text`, and a real (if small) citation
  behavior change: stored/cited chunk text is now always the original,
  un-enriched text, never whatever a `ChunkEnricher` produced.** Until
  now, `text` (used both for citations shown to the user and for the
  context fed to the answering LLM) was whatever the enricher returned —
  for Community's own heading-injection, a real but easy-to-miss
  side-effect: a citation could show an injected `[Article 42 — Title]`
  prefix that isn't verbatim what's at that exact position in the
  source. `text` is now always the chunk's real content; the enricher's
  output, when it differs, is stored separately as `retrieval_text` and
  used only to build the LLM's context (`api/query.rs`) — never shown to
  a user as if it were the source. `chunk_size` now matches `text`'s own
  length accordingly. `retrieval_text` is optional and
  `skip_serializing_if`, so points written before this field existed
  keep deserializing unchanged. The distinction matters even more for an
  enricher that adds generated text, which is not document content at
  all. 121 tests pass (five new), clippy stays clean.

- **New `EullmClient::model_id() -> &str`.** The configured model name
  was write-only (set in the constructor, never read back). Needed so
  a cache keyed on the model can read it from the same client instance
  doing the generation, instead of duplicating the configured model name
  as a second source of truth.

---

## [0.1.36] - 2026-08-21

### Changed

- **Chat column is now centered and wider.** The messages area and input
  bar had no max-width/centering wrapper of their own — only individual
  message bubbles capped at `max-w-3xl` — so on a wide screen bubbles sat
  flush against the far left/right edges of the whole `<main>` panel
  instead of reading as one centered column. Answers on documents like
  the EU AI Act run long, and the narrow 3xl cap meant a lot of line
  wrapping — i.e. more vertical scrolling than the actual text length
  warranted. Both the messages list and the input form are now wrapped in
  a centered `max-w-5xl` column, and bubbles widened from `max-w-3xl` to
  `max-w-[85%]` of that column.

---

## [0.1.35] - 2026-08-21

### Fixed

- **Ingestion crashed on real-world PDFs containing curly quotes, accents
  or em dashes.** `chunker::is_heading_line` (new in the heading-context
  feature above) sliced `line[..prefix.len()]` — a raw BYTE offset —
  which panics the instant a multi-byte character straddles that offset,
  taking the whole ingestion request down with it
  (`thread 'tokio-rt-worker' panicked ... is not a char boundary`).
  Reproduced on the real EU AI Act PDF within hours of shipping the
  heading-context feature. Rewritten to compare characters one at a time
  instead of byte-slicing — panic-free by construction regardless of
  content. New exhaustive test sweeps every prefix length × lead-in
  length combination with a multi-byte character landing at each
  possible offset, not just the one that happened to crash first.

- **Deleting a conversation with any messages in it always failed** with
  `FOREIGN KEY constraint failed (code 787)`. `chat_messages.conversation_id`
  has a (non-cascading) FK on `conversations(id)`
  (migrations/0002_conversations.sql) and sqlx enables
  `PRAGMA foreign_keys = ON` by default; `delete_conversation` deleted the
  parent row before its messages, which SQLite has always correctly
  refused. Fixed by deleting children before parent, within the same
  transaction. Both statements already filtered by `user_id` independently
  (not just `conv_id`), so reordering doesn't weaken the existing IDOR
  protection — see the updated doc comment on `delete_conversation`.

- **README quick-start couldn't actually be followed as written.** The
  release tarball is built as `tar czf ... -C stage .` — flat, no
  wrapping version-named folder inside it — but the quick-start snippet
  told users to `cd i3k-rag-engine-vX.Y.Z-linux-x86_64` right after
  `tar -xzf`, a directory that plain extraction never creates. Fixed to
  `mkdir` first. Also documented (new "Upgrading" section) that
  extracting a new release's tarball *over* an existing install reuses
  every already-downloaded component — `bootstrap::ensure_component`
  only fetches what's missing or sha256-mismatched, and `DATA__DIR`
  defaults to the binary's own directory — so this isn't a special
  workflow, just how the existing idempotent provisioning already
  behaves when pointed at a non-empty directory.

---

## [0.1.34] - 2026-08-21

### Added

- **Sources card now shows the page number(s) a chunk came from.** The
  API response has carried `page_start`/`page_end` since the Source
  Provenance Foundation work, but the frontend never rendered them —
  the sources list under an answer only showed filename + similarity
  %. `frontend/src/App.jsx` now adds a "pag. N" (or "pag. N–M" when a
  chunk spans multiple pages) badge next to each source, when the
  document has page info (non-PDF formats and documents ingested
  before this feature existed still have none, so the badge is
  omitted for those, not shown as blank/zero).

- **Chunks now carry the nearest preceding structural heading** ("Article
  99", "Chapter XII", "Section 4", ...) when they don't already contain
  it themselves. Root cause: chunk boundaries are byte-count-driven and
  know nothing about document structure, so a chunk can land entirely
  inside e.g. Article 100's body without the "Article 100" heading —
  which landed a chunk or two earlier. Retrieval then hands the LLM a
  fragment like "...administrative fines of up to EUR 1 500 000" with no
  indication of which article it belongs to. This is confirmed as the
  actual cause of two independently-built RAG stacks (this one and the
  old Python one) both misattributing the AI Act's Article 99/100/101
  penalty clauses to the wrong article on the same questions — verified
  against the real Official Journal PDF text, not assumed. New
  `chunker::detect_headings`/`inject_heading_context`: only touches the
  text that gets embedded/stored, not `Chunk.start_byte`/`end_byte` —
  page numbers and citation spans are unaffected. `CHUNKING_CONFIG_VERSION`
  bumped 1 → 2 (same chunk_index now stores different text than before,
  so re-ingesting must not collide with old provenance_ids).

---

## [0.1.33] - 2026-08-20

### Fixed (yet again)

- **`EULLM__MODEL_OVERRIDE` didn't stop the manifest-pinned qwen3-14b
  (8.4GB) from downloading anyway.** Same shape of bug as the bge-m3
  gguf one above: `select_components()` always selects "qwen3-14b" —
  a manifest model with no target, universal like every other model
  component — regardless of Settings, but `start_eullm` only ever
  falls back to it when `model_override` is unset. Once an override
  is set — a local path already on the machine, or a URL eullm
  fetches itself on `eullm run` — that download was never going to be
  read by anything. New `bootstrap::drop_unused_chat_model`, applied
  the same way as `drop_unused_embedding_model`, skips it whenever
  `EULLM__MODEL_OVERRIDE` is set, either form.

### Fixed (again)

- **bge-m3's GGUF was never going to resolve for eullm.** The manifest
  used to pin it as a component this binary downloaded directly via
  HTTP into eullm's model-store directory — but eullm's own model
  resolution (`resolve_model`) never downloads anything at request
  time; it only reads its store, mount points, or an explicit path
  (opt-in only). Removed `bge-m3-gguf` from manifest.toml entirely.
  It is now provisioned the correct way: `bootstrap::start_eullm`
  calls `eullm pull <url>` itself, once, the first time
  `ingestion_embedding=eullm` runs and the file isn't already
  present — idempotent and offline-safe like every other component,
  sha256-verified independently since a URL pull doesn't verify
  itself. Also fixes `config::EULLM_EMBEDDING_MODEL`, which was
  `"bge-m3"`: running a real pull against a real eullm 0.6.90 showed
  it actually registers as `"bge-m3-f16"` (derived from the pulled
  file's own name) — every `/api/embed` call under the old constant
  would have 404'd.

### Security

- **Qdrant no longer listens on all network interfaces.** The bundled
  qdrant binary defaults to `0.0.0.0` when its host isn't set —
  verified by running the actual pinned binary and reading its own
  startup log — and this project has no API key concept for it at
  all, so on any host where ports 6333/6334 weren't independently
  firewalled, the full REST+gRPC API (read, write, and delete every
  ingested document, completely unauthenticated) was reachable by
  anyone who could reach those ports, bypassing this binary's own JWT
  auth entirely. Now bound to `127.0.0.1` explicitly — this binary
  only ever talks to qdrant over localhost anyway, so nothing
  functional changes. Deployments with `DATA__MANAGE_SUBPROCESSES=false`
  (qdrant run externally) are unaffected either way — that qdrant's
  bind address was never this project's to control.
  eullm was checked too and needs no equivalent fix: it also listens
  on `0.0.0.0` at the socket level, but enforces its own IP allowlist
  at the application layer, loopback-only by default (`Allowed source
  IPs/subnets: 127.0.0.1/32, ::1/128`, per its own startup log) — a
  deliberate default, not an oversight.

### Fixed

- **Release tarballs did not include `.env.example`.** It existed in
  the repository since 0.1.32 but the packaging step never copied it
  into `stage/` alongside the binary, so anyone who downloaded a
  release instead of cloning the repo had no configuration template
  at all. Added to all three platform tarballs.

### Changed

- **`EMBEDDINGS__INGESTION_EMBEDDING=eullm` now also covers query-time
  embedding, not just ingestion.** Previously this mode only routed
  document-ingestion embedding through eullm's `POST /api/embed`;
  every question was still embedded through the in-process Candle
  instance regardless. Now both go through eullm, and Candle is not
  loaded at startup at all in this mode — not even on CPU — so
  bootstrap no longer downloads its ~2.1GB of bge-m3 weights either
  (only the ~1.1GB GGUF eullm itself uses). `Off` and `CandleGpu` are
  unaffected: query embedding still always uses Candle for those two,
  same as before. Worth knowing before enabling: on a card where
  bge-m3 and the chat model do not both fit in VRAM, every query now
  pays a potential model-swap round trip (evict chat to embed the
  question, evict bge-m3 back out to answer it) — see the doc comment
  on `config::IngestionEmbedding::Eullm`.

## [0.1.32] - 2026-08-20

### Fixed

- **`Settings::load()` rejected the minimal `.env` README.md has
  documented since 0.1.28.** Every field of `EullmSettings` already
  had its own default, but the `Settings.eullm` field itself had no
  `#[serde(default)]` and `EullmSettings` had no `Default` impl — with
  zero `EULLM__*` variables set, config loading failed outright with
  "missing field `eullm`" before ever reaching the individual fields'
  defaults. Verified against the actual compiled binary, not just the
  struct definitions: running it with only `AUTH__JWT_SECRET` set
  reproduced the failure before the fix, and reached the real
  bootstrap/download flow after it. Every other documented `.env`
  example (`BUILD.md`) happened to already set `EULLM__URL`/
  `EULLM__MODEL` explicitly, which is why this went unnoticed.

### Added

- `EULLM__REPEAT_LAST_N` — how many recent tokens `repeat_penalty`
  looks back over, previously hardcoded to 256 with no way to change
  it short of a rebuild. Default unchanged (256).
- `.env.example` at the repo root, documenting every `SECTION__FIELD`
  variable `Settings::load()` reads.

## [0.1.31] - 2026-08-20

### Added

- **Source Provenance Foundation.** Every retrieved chunk now carries a
  byte-offset span (`source_start`/`source_end`) into its source
  document, a PDF page span (`page_start`/`page_end`, for both the
  native `pdf_oxide` path and the OCR fallback), and a deterministic
  `provenance_id` anchored to the uploaded file's own sha256 — stable
  across re-ingestion of an unchanged file, and versioned so a later
  chunking/extraction config change produces visibly distinct ids
  instead of silent collisions. Infrastructural only: this is not
  claim-level (sentence) attribution, source highlighting, or
  NLI-based verification — those stay roadmap items. All new fields
  are optional; points written before this change deserialize them as
  absent, no re-ingestion required. See `rag::chunker::provenance_id`
  and `documents::parser::PageSpan`.

### Fixed

- **eullm never started on a GPU-less Linux x86_64 host.** The
  manifest's only `linux-x86_64` eullm pin required CUDA; a machine
  without an NVIDIA GPU found no usable target and bootstrap silently
  fell back to no LLM. Added the missing CPU-only entry (mirrors the
  ARM64 fix from 0.1.28).
- `--embedding-model` is now gated behind a separate
  `EullmSettings::reserve_embedding_model` flag (default off) instead
  of firing automatically whenever ingestion embedding runs through
  eullm — on a tight-VRAM card it was reserving space for bge-m3
  before `--fit` sized the chat model, starving it. Deployments with
  headroom for both can opt in explicitly.

### Changed

- CI no longer builds or publishes the Candle-CUDA Linux release
  variants (`release-linux-{x86_64,arm64}-cuda`): eullm's own bundled
  CUDA already covers GPU-accelerated embedding
  (`/api/embed` since 0.6.82, `--embedding-model` since 0.6.90), making
  a second CUDA toolchain compiled into this binary redundant. The
  source (`--features cuda`) stays buildable by hand; this only stops
  CI from shipping it. Every platform now ships one CPU-only tarball,
  matching how Windows was already described — a GPU is still used
  automatically wherever eullm detects one at runtime, regardless of
  how this binary itself was compiled.
- `manifest.toml` also pins the `eullm-linux-x64-vulkan` asset
  (sha256/size verified against the real downloaded binary). Not yet
  selectable — no Vulkan-GPU detection exists in `current_targets()`
  — pinned in advance so the entry is ready once that detection is
  written.

## [0.1.30] - 2026-08-18

### Added

- **Document-ingestion embedding through eullm.** `EMBEDDINGS__INGESTION_EMBEDDING=eullm`
  routes the embedding step of document ingestion through eullm's own
  `POST /api/embed` (eullm ≥ 0.6.82) instead of the in-process Candle path —
  an alternative for GPU-accelerated embedding that does not need this
  binary itself compiled with `--features cuda`, since eullm manages its own
  device placement. Query-time embedding is unaffected either way: it always
  runs through the resident Candle instance, a single short text per
  request. Off by default; existing deployments see no change unless this is
  set. See `config::IngestionEmbedding` for the two other explicit modes
  (`candle_gpu`, the pre-existing CPU↔GPU swap; `off`, unchanged).

  With eullm ≥ 0.6.90, `bootstrap::spawn_eullm` also passes
  `--embedding-model` at startup, so bge-m3 loads as a reserved companion
  next to the chat model when there is room for both — decided once, inside
  eullm, instead of gambled on which of two independently-started processes
  happened to claim VRAM first.

### Changed

- `manifest.toml`'s eullm fleet moves to 0.6.90 (all six pinned targets).

## [0.1.28] - 2026-08-17

### Added

- **Native Windows x86_64 support**, CPU and CUDA. `i3k-rag-engine.exe`
  cross-compiles from a Linux host (no Windows runner needed) — see
  BUILD.md's "Windows (cross-compiled from Linux, CPU only)". OCR
  (Tesseract 5.5.0 + Leptonica 1.85.0) is built statically for the release
  tarball, no runtime mingw dependency; the engine binary itself still needs
  `libstdc++-6.dll` bundled alongside it, a dependency Tesseract's own build
  does not have. Embedding is CPU-only on this platform (Candle's CUDA
  support is not cross-compiled for Windows); eullm — a separate process —
  still uses the GPU when one is present, so chat inference is accelerated
  regardless.
- OCR no longer needs a build-time `--features ocr` flag: `libtesseract` and
  `libleptonica` load at runtime through `libloading`, from an explicit path
  next to the executable, the same pattern already used for `libpdfium`. It
  is always compiled in now.

---

## [0.1.27] - 2026-08-14

### Added

- **Restore.** `POST /api/admin/backup/restore` puts an archive back, as the
  exact inverse of the backup that produced it: the Qdrant snapshot is uploaded
  with `priority=snapshot` so the archived vectors win, and every table the
  archive shares with the live schema is replaced inside one transaction. Until
  now a backup could be taken and listed but never used, which made the whole
  feature ornamental.

  Details worth knowing before running it:

  - It **replaces**, it does not merge. Rows created after the backup are gone.
  - Qdrant is restored first. If that fails nothing else is touched, so a failed
    restore leaves the installation as it was rather than stranding fresh
    metadata against old vectors.
  - An archive older than the current schema still restores: tables that no
    longer exist are skipped, and columns added by a later migration keep their
    default.
  - `_sqlx_migrations` is never copied back — the schema belongs to the binary
    that is running, not to the archive.
  - The response reports what was actually restored, because an archive taken
    while Qdrant was unreachable contains no snapshot.

  Verified end to end against a running Qdrant 1.18.2, not only in unit tests:
  seed a collection, back it up, add a point and a row, restore, and check that
  both additions are gone and the archived state is back. That test is
  `#[ignore]`d by default and runs with
  `QDRANT_URL_FOR_TEST=… cargo test qdrant_round_trip -- --ignored`.

- **Backups are verified, twice.** A backup nobody has checked is a guess, and
  the guess is only tested on the day it has to work.

  When the archive is written: the SQLite copy is reopened and put through
  `PRAGMA integrity_check`, and the Qdrant snapshot is checked against the size
  and sha256 Qdrant itself reports for it — a truncated download used to be
  written out silently. Each member's digest goes into a `backup.json` inside
  the archive.

  When it is restored: every member is checked against that manifest **before
  anything is written**. A damaged archive stops there, with the installation
  untouched, instead of being discovered halfway through.

  Two failures are now told apart. If Qdrant answers with a snapshot that does
  not match what it says it made, the backup fails outright — a verifiably
  broken archive must never reach the backup directory. If Qdrant does not
  answer at all, the archive is still written, without vectors, and says so:
  losing today's copy of the users and the document metadata as well would be
  worse, and the gap is recorded rather than hidden.

  Archives written by 0.1.25 and 0.1.26 carry no manifest. They still restore,
  and the response reports `verified: false` so it is clear they could not be
  checked.

### Fixed

- The Qdrant snapshot was downloaded and written with nothing verified at all.
  A truncated HTTP body is not an error — it just leaves a shorter file — so a
  half-downloaded snapshot was archived as though it were sound.
- `backup/mod.rs` described the archive as including an "optional rclone
  upload". There is no rclone anywhere in this codebase and never was; backups
  are local files and nothing is uploaded anywhere.

---

## [0.1.26] - 2026-08-13

### Changed

- **The first run downloads 5 GB less** — `qwen3-8b` was pinned in
  `manifest.toml` but referenced nowhere in the code, left over from a pipeline
  this engine does not have. The first run goes from ~17.3 GB to ~12.3 GB. Every
  component is still verified against a pinned sha256 before use. An existing
  installation can delete `models/qwen3-8b/` to reclaim the space.
- `EULLM__MODEL` now defaults to `qwen3-14b` and is no longer required. Starting
  without it used to fail, for a setting the default configuration then ignores:
  when the engine launches eullm itself it passes the GGUF path from the
  manifest. It still applies if you run eullm separately and point the engine at
  it. `AUTH__JWT_SECRET` is now the only setting with no default.
- Remaining Italian text translated to English: the 503 returned while a document
  is being ingested, the errors reported when the first run cannot download or
  verify a component, and the stage labels of the `--bench` report.
- README: documents what actually changed between the `1.x` Python stack and
  this one, and states that the two cannot run side by side — they contend for
  ports 8000, 6333 and 11434, so the Compose stack must be stopped first. The
  `1.x` volumes are left in place, so going back remains possible.

### Fixed

- `Cargo.toml` declared `MIT OR Apache-2.0`; this project is Apache-2.0, as
  `LICENSE` has always said.
- The README still advertised a 17 GB first-run download after the manifest had
  changed, and still listed `EULLM__MODEL` as required after it had been given a
  default.

### Removed

- The `license/` module — dead code (`check_page_limit` was never called) that
  described a commercial gating model not implemented here, and pulled in
  `ed25519-dalek` for nothing.
- Source comments referencing files and internal documents absent from this
  repository, some of which described unreleased plans. Three stale `TODO`
  markers on code that has been complete and working for a long time.

### Notes

No changes to retrieval, ingestion, chunking, embeddings or the HTTP API.
Upgrading is a matter of replacing the binary; data and Qdrant collections are
untouched.

---

## [0.1.25] - 2026-08-13

First public release of the Rust rewrite. The system is now a **single binary**
with no Docker, no Compose and no Java: on first run it downloads and
sha256-verifies everything it needs — vector database, inference engine, models,
OCR data — and supervises those processes itself. After that it needs no network
at all.

### Added

- Single self-contained binary for Linux x86\_64 and arm64, with and without
  CUDA, each published as a release tarball.
- Component bootstrap driven by `manifest.toml`: every download is pinned by
  sha256 and size, and a mismatch aborts the run. Platform variants are selected
  at runtime, including a CIX P1 build of the inference engine gated on actual
  CPU feature detection rather than on the SoC name.
- Embeddings in-process via [Candle](https://github.com/huggingface/candle)
  (BAAI/bge-m3, 1024 dimensions), on GPU or CPU, with
  `EMBEDDINGS__REQUIRE_GPU` to refuse to start rather than silently degrade to a
  much slower CPU path.
- LLM inference through [eullm](https://github.com/eullm/eullm) as a supervised
  subprocess, with VRAM handed back and forth around ingestion.
- Document ingestion for PDF (including scanned pages via OCR), DOCX, XLSX, HTML,
  TXT, Markdown and CSV. Scanned pages are detected automatically and passed
  through Tesseract in Italian and English.
- JWT authentication with three roles — user, super user, admin.
- Streaming answers over SSE, with conversation history carried into follow-ups.
- Scheduled backups of the SQLite database and the Qdrant collection together, so
  a restore brings back a consistent pair.
- `--bench` writes a Markdown report timing each stage of ingestion and inference
  on your own hardware and document; `--bench-live` records a whole session
  instead and reports on shutdown.

### Changed

- Apache-2.0, with a full third-party inventory in
  [THIRD\_PARTY\_LICENSES.md](THIRD_PARTY_LICENSES.md).
- The Python stack is preserved unchanged on
  [`python-legacy`](../../tree/python-legacy) and in the `1.x` tags. There is no
  automatic migration path: stop the Compose stack, re-upload the documents, then
  decommission it once satisfied.

---

## [1.2.1] - 2026-05-27

### Added

- `.zenodo.json` with project metadata, keywords, ORCID-linked author and
  licence, enabling automatic DOI generation via [Zenodo](https://zenodo.org/)
  so the project is citable as a research output. ORCID iD:
  [0009-0003-8613-3065](https://orcid.org/0009-0003-8613-3065).

No functional changes from 1.2.0.

---

## [1.2.0] - 2026-03-02

### Added

- **Multi-GPU support** — NVIDIA (CUDA), AMD (ROCm) and CPU-only modes
  ([#9](https://github.com/I3K-IT/RAG-Enterprise/issues/9))
  - New `GPU_TYPE` setting in `.env` (`nvidia`, `amd`, `cpu`)
  - Docker Compose override files: `docker-compose.nvidia.yml` (NVIDIA CUDA),
    `docker-compose.amd.yml` (AMD ROCm)
  - Setup wizard now asks GPU type and auto-configures the correct Docker images
    and device mappings
  - AMD uses the `ollama/ollama:rocm` image with `/dev/kfd` and `/dev/dri`
    device passthrough
  - CPU-only mode works out of the box with no GPU drivers required

---

## [1.1.5] - 2026-03-01

### Added

- **Automatic model download at startup** — if the configured LLM model is not
  present in Ollama, the backend downloads it showing real-time progress:
  percentage, downloaded/total size, speed and estimated time remaining
- **Ollama readiness check** — the backend waits for Ollama to be reachable
  before proceeding, preventing 404/connection errors on fresh installations

### Fixed

- **Ollama URL now configurable** via `OLLAMA_HOST` and `OLLAMA_PORT` environment
  variables — previously hardcoded to `http://ollama:11434`, which only worked
  inside Docker networking
- Replaced stale `MILVIUS_HOST`/`MILVIUS_PORT` env vars in the Dockerfile with
  correct `OLLAMA_HOST`/`OLLAMA_PORT` defaults

---

## [1.1.0] - 2026-02-27

### Added

- **Backup & Restore system** with full admin panel UI
  - One-click local backup of database, documents and vector store
  - Cloud backup via rclone (70+ providers: Mega, S3, Google Drive, OneDrive,
    Dropbox, WebDAV, FTP, SFTP, B2, pCloud)
  - Automatic scheduled backups with cron expressions and configurable retention
    policies
  - Selective restore (choose which components to restore individually)
  - Cloud provider management with connection testing
  - Backup history tracking (last 100 operations)
  - Download backups from cloud to local storage
- Complete backup documentation (`docs/BACKUP.md`) with setup guides for all
  providers
- rclone pre-installed in the Docker image for cloud storage integration

### Security

- All backup endpoints require admin role authentication
- Cloud provider passwords encrypted via rclone obscure mechanism
- Path traversal protection on archive extraction during restore
- Safe online SQLite backup (no downtime, no data corruption)

---

## [1.0.0] - 2026-02-21

First public release of RAG Enterprise — a 100% local Retrieval-Augmented
Generation system for organisations that need complete data privacy.

### Added

- One-command setup with Docker Compose (`setup.sh`)
- Multi-format document processing (PDF, DOCX, PPTX, XLSX, TXT, MD, ODT, RTF,
  HTML, XML)
- Local LLM inference via Ollama (Qwen3 14B Q4, Mistral 7B Q4)
- Vector search with Qdrant and BAAI/bge-m3 multilingual embeddings
- OCR pipeline for scanned documents (Tesseract + Apache Tika)
- JWT authentication with role-based access control (user / super user / admin)
- Conversational memory per user with session isolation
- GPU acceleration support (NVIDIA CUDA)
- 29-language support for document processing and retrieval
- React + Vite frontend with Tailwind CSS
- Auto-configuration of network and security during setup
- Smart PDF detection and routing (digital vs scanned)
- Benchmark script for performance testing
- Community files: contributing guide, issue templates, PR template, roadmap
- Qdrant API key support for secured deployments

### Security

- Production-ready JWT + CORS configuration
- Conversation isolation between users
- Removal of all hardcoded credentials
- Automatic security configuration during setup

### Performance

- Direct Ollama API client replacing the LangChain wrapper
- Optimised RAG search parameters for large documents
- GPU memory management with automatic CPU fallback
- Tika heap tuning (4 GB) with auto-restart on failure
- Robust timeout and auto-recovery for document processing
- Thread pool execution for document processing, to avoid blocking the event loop
- OOM crash prevention on sequential document uploads

### Fixed

- PyTorch and CUDA compatibility across GPU generations
- Embedding batch size tuning with CUDA fallback
- HTTP enforcement for local Qdrant connections
- Benchmark script authentication and output paths
- PaddleOCR / PyMuPDF dependency conflict resolution

### Changed

- LLM switched from Qwen 2.5 to Qwen3 14B Q4\_K\_M for improved quality
- All Italian text translated to English for international accessibility

---

[Unreleased]: https://github.com/I3K-IT/RAG-Enterprise/compare/v0.1.27...HEAD
[0.1.27]: https://github.com/I3K-IT/RAG-Enterprise/compare/v0.1.26...v0.1.27
[0.1.26]: https://github.com/I3K-IT/RAG-Enterprise/compare/v0.1.25...v0.1.26
[0.1.25]: https://github.com/I3K-IT/RAG-Enterprise/releases/tag/v0.1.25
[1.2.1]: https://github.com/I3K-IT/RAG-Enterprise/releases/tag/v1.2.1
[1.2.0]: https://github.com/I3K-IT/RAG-Enterprise/releases/tag/1.2.0
[1.1.5]: https://github.com/I3K-IT/RAG-Enterprise/releases/tag/1.1.5
[1.1.0]: https://github.com/I3K-IT/RAG-Enterprise/releases/tag/1.1.0
[1.0.0]: https://github.com/I3K-IT/RAG-Enterprise/releases/tag/1.0.0
