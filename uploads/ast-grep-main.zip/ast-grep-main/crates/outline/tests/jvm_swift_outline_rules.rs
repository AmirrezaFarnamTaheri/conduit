use ast_grep_language::SupportLang;

mod common;

#[test]
fn kotlin_rules_parse_and_extract_okhttp_shapes() {
  const RULES: &str = include_str!("../src/default_rules/kotlin.yml");
  common::assert_outline_snapshot(
    SupportLang::Kotlin,
    RULES,
    r#"
package okhttp3.sse

import okhttp3.Request
import java.io.IOException as IOE

public interface Interceptor {
  fun intercept(chain: Chain): Response
}

@Serializable
sealed class AnnotatedBox

fun interface FunctionalApi {
  fun invoke(): Unit
}

value class UserId(val value: String)

class RealInterceptorChain constructor(val call: Call) {
  internal constructor(call: Call, index: Int) : this(call)
  override fun proceed(request: Request): Response { return TODO() }
  fun exchange(): Exchange = TODO()
  val index: Int = 0
  internal fun copy(index: Int = 0) = RealInterceptorChain(call)
  override fun withConnectTimeout(timeout: Int, unit: TimeUnit): Interceptor.Chain {
    return copy()
  }
}

public object EventSources {
  fun createFactory(): Factory = TODO()
}

enum class Protocol { HTTP_1_1 }

class RealCall {
  override fun execute(): Response {
    return getResponseWithInterceptorChain()
  }
  override fun isExecuted(): Boolean = TODO()
  private fun callStart() {}
  @Throws(IOException::class)
  internal fun getResponseWithInterceptorChain(): Response {
    val localResponse: Response = TODO()
    var localCalls: Int = 0
    return localResponse
  }
}

class ScopeBox {
  val direct: Int = 0
  class Nested {
    fun leaked(): Unit {}
    val nestedValue: Int = 0
  }
  companion object {
    fun companionLeak(): Unit {}
    val companionValue: Int = 0
  }
  fun directFun() {}
}
"#,
    r#"
- Module import private okhttp3.Request
- Module import private IOE
- Interface item exported Interceptor
  - Method public intercept
- Class item exported AnnotatedBox
- Interface item exported FunctionalApi
  - Method public invoke
- Class item exported UserId
- Class item exported RealInterceptorChain
  - Constructor private constructor
  - Method public proceed
  - Method public exchange
  - Property public index
  - Method private copy
  - Method public withConnectTimeout
- Object item exported EventSources
  - Method public createFactory
- Enum item exported Protocol
- Class item exported RealCall
  - Method public execute
  - Method public isExecuted
  - Method private callStart
  - Method private getResponseWithInterceptorChain
- Class item exported ScopeBox
  - Property public direct
  - Class public Nested
  - Object public companion object
  - Method public directFun
"#,
  );
}

#[test]
fn kotlin_rules_extract_signatures() {
  const RULES: &str = include_str!("../src/default_rules/kotlin.yml");
  common::assert_outline_signature_snapshot(
    SupportLang::Kotlin,
    RULES,
    r#"
package okhttp3.sse

import okhttp3.Request
import java.io.IOException as IOE

class RealInterceptorChain constructor(val call: Call) {
  internal constructor(call: Call, index: Int) : this(call)
  override fun proceed(request: Request): Response { return TODO() }
  val index: Int = 0
}
"#,
    r#"
- Module import private okhttp3.Request | import okhttp3.Request
- Module import private IOE | import java.io.IOException as IOE
- Class item exported RealInterceptorChain | class RealInterceptorChain constructor(val call: Call) {
  - Constructor private constructor | internal constructor(call: Call, index: Int) : this(call)
  - Method public proceed | override fun proceed(request: Request): Response { return TODO() }
  - Property public index | val index: Int = 0
"#,
  );
}

#[test]
fn java_rules_parse_and_extract_jvm_surface() {
  const RULES: &str = include_str!("../src/default_rules/java.yml");
  common::assert_outline_snapshot(
    SupportLang::Java,
    RULES,
    r#"
package okhttp3;

import okhttp3.Request;
import static java.util.Collections.emptyList;

public interface Interceptor {
  Response intercept(Chain chain) throws IOException;
}

@Deprecated public interface AnnotatedApi {
  static public Response reordered();
}

public final class RealInterceptorChain implements Interceptor {
  private final int index;
  @Deprecated public final int publicFinalField;
  final int packagePrivateFinalField;
  public RealInterceptorChain(int index) { this.index = index; }
  public Response proceed(Request request) throws IOException { return null; }
  Response exchange() { return null; }
}

enum Protocol { HTTP_1_1 }
"#,
    r#"
- Module import private okhttp3.Request
- Module import private java.util.Collections.emptyList
- Interface item exported Interceptor
  - Method private intercept
- Interface item exported AnnotatedApi
  - Method public reordered
- Class item exported RealInterceptorChain
  - Field private index
  - Field public publicFinalField
  - Field private packagePrivateFinalField
  - Constructor public RealInterceptorChain
  - Method public proceed
  - Method private exchange
- Enum item private Protocol
  - EnumMember public HTTP_1_1
"#,
  );
}

#[test]
fn java_rules_parse_and_extract_enum_members() {
  const RULES: &str = include_str!("../src/default_rules/java.yml");
  common::assert_outline_snapshot(
    SupportLang::Java,
    RULES,
    r#"
enum Colors {
  RED,
  GREEN;
}

enum Empty {}
"#,
    r#"
- Enum item private Colors
  - EnumMember public RED
  - EnumMember public GREEN
- Enum item private Empty
"#,
  );
}

#[test]
fn java_rules_parse_and_extract_module_declaration() {
  const RULES: &str = include_str!("../src/default_rules/java.yml");
  common::assert_outline_snapshot(
    SupportLang::Java,
    RULES,
    r#"
module com.example {
  requires java.base;
}
"#,
    r#"
- Module item exported com.example
"#,
  );
}

#[test]
fn java_rules_parse_wildcard_imports() {
  const RULES: &str = include_str!("../src/default_rules/java.yml");
  common::assert_outline_snapshot(
    SupportLang::Java,
    RULES,
    r#"
package okhttp3;

import java.util.*;
import static java.util.Map.*;
import java.*;
import static java.lang.*;
import okhttp3.Request;
import static java.util.Collections.emptyList;

class Client {}
"#,
    r#"
- Module import private java.util.*
- Module import private java.util.Map.*
- Module import private java.*
- Module import private java.lang.*
- Module import private okhttp3.Request
- Module import private java.util.Collections.emptyList
- Class item private Client
"#,
  );
}

#[test]
fn java_member_visibility_is_reported_for_every_member() {
  const RULES: &str = include_str!("../src/default_rules/java.yml");
  common::assert_outline_snapshot(
    SupportLang::Java,
    RULES,
    r#"
class C {
  private int privateField;
  protected int protectedField;
  int packagePrivateField;
  public int publicField;
  private void privateMethod() {}
  protected void protectedMethod() {}
  void packagePrivateMethod() {}
  public void publicMethod() {}
  private C() {}
  C(int value) {}
  public C(int value, int other) {}
}
"#,
    r#"
- Class item private C
  - Field private privateField
  - Field private protectedField
  - Field private packagePrivateField
  - Field public publicField
  - Method private privateMethod
  - Method private protectedMethod
  - Method private packagePrivateMethod
  - Method public publicMethod
  - Constructor private C
  - Constructor private C
  - Constructor public C
"#,
  );
}

#[test]
fn java_rules_parse_and_extract_annotation_types() {
  const RULES: &str = include_str!("../src/default_rules/java.yml");
  common::assert_outline_snapshot(
    SupportLang::Java,
    RULES,
    r#"
public @interface Marker {}

@interface Config {
  String value();
  @interface Nested { boolean leaked(); }
  class Helper { @interface Deeper { int leaked(); } }
  int count() default 0;
}
"#,
    r#"
- Interface item exported Marker
- Interface item private Config
  - Method public value
  - Method public count
"#,
  );
}

#[test]
fn java_rules_parse_and_extract_records() {
  const RULES: &str = include_str!("../src/default_rules/java.yml");
  common::assert_outline_snapshot(
    SupportLang::Java,
    RULES,
    r#"
public record Point(int x, int y) {
  public double norm() { return 0; }
}

record Internal(int value) {}
"#,
    r#"
- Struct item exported Point
  - Method public norm
- Struct item private Internal
"#,
  );
}

#[test]
fn java_rules_parse_and_extract_compact_constructors() {
  const RULES: &str = include_str!("../src/default_rules/java.yml");
  common::assert_outline_snapshot(
    SupportLang::Java,
    RULES,
    r#"
public record Point(int x, int y) {
  public Point {
    if (x < 0) { throw new IllegalArgumentException(); }
  }
  public double norm() { return 0; }
}

record Internal(int value) {}
"#,
    r#"
- Struct item exported Point
  - Constructor public Point
  - Method public norm
- Struct item private Internal
"#,
  );
}

#[test]
fn java_rules_extract_duplicate_method_names_with_signatures() {
  const RULES: &str = include_str!("../src/default_rules/java.yml");
  common::assert_outline_signature_snapshot(
    SupportLang::Java,
    RULES,
    r#"
public class Parser {
  public Node parse(String input) {
    return null;
  }

  public Node parse(byte[] input) {
    return null;
  }

  Node parse(int count) {
    return null;
  }
}
"#,
    r#"
- Class item exported Parser | public class Parser {
  - Method public parse | public Node parse(String input) {
  - Method public parse | public Node parse(byte[] input) {
  - Method private parse | Node parse(int count) {
"#,
  );
}

#[test]
fn swift_rules_parse_and_extract_alamofire_shapes() {
  const RULES: &str = include_str!("../src/default_rules/swift.yml");
  common::assert_outline_snapshot(
    SupportLang::Swift,
    RULES,
    r#"
import Foundation
@preconcurrency import Dispatch

public final class Session {
  public init(configuration: URLSessionConfiguration) {}
  open func request(_ convertible: any URLConvertible) -> DataRequest { fatalError() }
}

@MainActor public final class ActorSession {
  @MainActor public func refresh() {}
}

public protocol RequestInterceptor: Sendable {
  func adapt(_ urlRequest: URLRequest) throws -> URLRequest
}

public enum AFError: Error {
  case invalidURL(url: any URLConvertible)
}

public struct HTTPHeaders: Sendable {
  public init(_ headers: [HTTPHeader]) {}
}

@frozen public struct Tagged {
  public init() {}
}

@MainActor public enum AnnotatedError {
  case failed
}

@MainActor public actor Loader {
  public init() {}
  public func load() {}
}

@MainActor public func makeSession() {}

class InternalBox {
  init() {}
  func helper() -> Int { return 1 }
}
"#,
    r#"
- Module import private Foundation
- Module import private Dispatch
- Class item exported Session
  - Constructor public init
  - Method public request
- Class item exported ActorSession
  - Method public refresh
- Interface item exported RequestInterceptor
  - Method public adapt
- Enum item exported AFError
- Struct item exported HTTPHeaders
  - Constructor public init
- Struct item exported Tagged
  - Constructor public init
- Enum item exported AnnotatedError
- Object item exported Loader
  - Constructor public init
  - Method public load
- Function item exported makeSession
- Class item private InternalBox
  - Constructor private init
  - Method private helper
"#,
  );
}

#[test]
fn swift_rules_extract_signatures() {
  const RULES: &str = include_str!("../src/default_rules/swift.yml");
  common::assert_outline_signature_snapshot(
    SupportLang::Swift,
    RULES,
    r#"
@preconcurrency import Dispatch

public final class Session {
  public init(configuration: URLSessionConfiguration) {}
  open func request(_ convertible: any URLConvertible) -> DataRequest { fatalError() }
}

public protocol RequestInterceptor: Sendable {
  func adapt(_ urlRequest: URLRequest) throws -> URLRequest
}

@MainActor public func makeSession() {}
"#,
    r#"
- Module import private Dispatch | @preconcurrency import Dispatch
- Class item exported Session | public final class Session {
  - Constructor public init | public init(configuration: URLSessionConfiguration) {}
  - Method public request | open func request(_ convertible: any URLConvertible) -> DataRequest { fatalError() }
- Interface item exported RequestInterceptor | public protocol RequestInterceptor: Sendable {
  - Method public adapt | func adapt(_ urlRequest: URLRequest) throws -> URLRequest
- Function item exported makeSession | @MainActor public func makeSession() {}
"#,
  );
}
