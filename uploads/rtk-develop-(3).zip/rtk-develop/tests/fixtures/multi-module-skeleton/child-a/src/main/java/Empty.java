public class Empty {}
