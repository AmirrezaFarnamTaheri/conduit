#![cfg(unix)]
//! For un-capped searches `rtk grep X` must be byte-identical to `grep X`.
//! Every scenario runs twice, with and without `-n`, so both the presence and
//! the absence of the line number are pinned: grep prints one only when asked,
//! and the filename only when it would itself. Covers content and regex edge
//! cases (colons, digits, shell metachars, unicode, colon-in-path) that must
//! never be misparsed.

use std::io::Write;
use std::process::{Command, Stdio};

mod common;

fn rtk_grep(args: &[&str]) -> (String, Option<i32>) {
    let mut a = vec!["grep"];
    a.extend_from_slice(args);
    let out = common::rtk_command().args(&a).output().expect("rtk");
    (
        String::from_utf8_lossy(&out.stdout).into_owned(),
        out.status.code(),
    )
}

fn grep_plain(args: &[&str]) -> (String, Option<i32>) {
    let out = common::native_command("grep")
        .args(args)
        .output()
        .expect("grep");
    (
        String::from_utf8_lossy(&out.stdout).into_owned(),
        out.status.code(),
    )
}

fn assert_eq_grep(args: &[&str]) {
    let (rtk, rc) = rtk_grep(args);
    let (grep, gc) = grep_plain(args);
    assert_eq!(rtk, grep, "stdout mismatch for {args:?}");
    assert_eq!(rc, gc, "exit code mismatch for {args:?}");
}

fn assert_eq_grep_with_and_without_n(args: &[&str]) {
    assert_eq_grep(args);
    let mut with_n = vec!["-n"];
    with_n.extend_from_slice(args);
    assert_eq_grep(&with_n);
}

/// A file list (`-l`/`-L`) is the one passthrough RTK reshapes: when two or more paths share
/// a directory, that prefix is folded into a `<prefix> (N files)` header. Rebuild the paths
/// from the header and require the result to equal grep's list, path for path and in order;
/// with fewer than two paths there is no header and the output must be byte-identical.
fn assert_eq_grep_file_list(args: &[&str]) {
    let (rtk, rc) = rtk_grep(args);
    let (grep, gc) = grep_plain(args);
    assert_eq!(rc, gc, "exit code mismatch for {args:?}");
    let unfolded = match rtk.lines().next().and_then(|h| h.strip_suffix(" files)")) {
        Some(head) => {
            let (prefix, n) = head.rsplit_once(" (").expect("header shape");
            let tails: Vec<&str> = rtk.lines().skip(1).collect();
            assert_eq!(
                tails.len(),
                n.parse::<usize>().unwrap(),
                "count for {args:?}"
            );
            tails.iter().map(|t| format!("{prefix}{t}\n")).collect()
        }
        None => rtk.clone(),
    };
    assert_eq!(unfolded, grep, "file list mismatch for {args:?}:\n{rtk}");
}

fn write(dir: &std::path::Path, name: &str, body: &str) -> String {
    let p = dir.join(name);
    std::fs::write(&p, body).expect("write");
    p.to_str().unwrap().to_string()
}

#[test]
fn single_multi_recursive_and_h_match_grep() {
    let d = tempfile::tempdir().unwrap();
    let f1 = write(d.path(), "f1.txt", "apple\nzebra apple\nbanana\n");
    let f2 = write(d.path(), "f2.txt", "apricot\n");
    assert_eq_grep_with_and_without_n(&["apple", &f1]); // single: no filename
    assert_eq_grep_with_and_without_n(&["a", &f1, &f2]); // multi: filename
    assert_eq_grep_with_and_without_n(&["-H", "apple", &f1]); // -H forces filename
    assert_eq_grep_with_and_without_n(&["-r", "a", d.path().to_str().unwrap()]);
}

#[test]
fn no_match_matches_grep() {
    let d = tempfile::tempdir().unwrap();
    let f = write(d.path(), "f.txt", "hello\n");
    assert_eq_grep_with_and_without_n(&["zzz_no_match_xyz", &f]); // empty stdout, exit 1
}

#[test]
fn nasty_content_is_not_misparsed() {
    let d = tempfile::tempdir().unwrap();
    let f = write(
        d.path(),
        "n.txt",
        "12:34 looks like a line number\na::b::c ClassRegistry::init('x')\nport :8080: here\n$(rm -rf /) `whoami` && echo\n中文 テスト مرحبا\n",
    );
    assert_eq_grep_with_and_without_n(&[":", &f]);
    assert_eq_grep_with_and_without_n(&["ClassRegistry", &f]);
    assert_eq_grep_with_and_without_n(&["中文", &f]);
    assert_eq_grep_with_and_without_n(&["whoami", &f]);
}

#[test]
fn regex_metacharacters_match_grep() {
    let d = tempfile::tempdir().unwrap();
    let f = write(d.path(), "r.txt", "a.b\naxb\nfoo.bar\n[x]\n");
    assert_eq_grep_with_and_without_n(&["a.b", &f]); // . is any-char
    assert_eq_grep_with_and_without_n(&["-F", "a.b", &f]); // fixed-string
    assert_eq_grep_with_and_without_n(&["^foo", &f]); // anchor
    assert_eq_grep_with_and_without_n(&["-E", "ax?b", &f]); // ERE
}

#[test]
fn context_flags_match_grep() {
    let d = tempfile::tempdir().unwrap();
    let f = write(d.path(), "c.txt", "x\nMATCH\ny\nz\n");
    assert_eq_grep_with_and_without_n(&["-A1", "MATCH", &f]);
    assert_eq_grep_with_and_without_n(&["-B1", "MATCH", &f]);
    assert_eq_grep_with_and_without_n(&["-C1", "MATCH", &f]);
}

#[test]
fn context_group_separator_matches_grep() {
    let d = tempfile::tempdir().unwrap();
    let f = write(
        d.path(),
        "sep.txt",
        "match A\nfill1\nfill2\nfill3\nmatch B\n",
    );
    assert_eq_grep_with_and_without_n(&["-A1", "match", &f]);
}

// #1436: a single-file `-n` search with `::` content and a BRE pattern with
// literal `()` must equal grep exactly — no broadened matches, and no synthetic
// `[file]` bucket from splitting on `::`.
#[test]
fn issue_1436_colons_and_literal_parens() {
    let d = tempfile::tempdir().unwrap();
    let f = write(
        d.path(),
        "shell.php",
        "use Util\\ClassRegistry;\nclass Foo {\n    public function run() {\n        $this->m = ClassRegistry::init('Collections.QueueProcess');\n        try {\n            deleteRow($id);\n            $this->delete();\n        } catch (\\Exception $e) {\n        } finally {}\n    }\n    private function delete() {}\n}\n",
    );
    assert_eq_grep_with_and_without_n(&[
        "private function delete\\|try\\|catch\\|finally\\|delete()",
        &f,
    ]);
    assert_eq_grep_with_and_without_n(&["init", &f]); // ClassRegistry::init must stay one intact line
}

// #1436 (comments): a leading `^` anchor must stay scoped to the given file
// (tenequm), and a line ending in `:` (Python `if x:`) must keep full content
// (BTCAlchemist).
#[test]
fn issue_1436_anchor_scope_and_trailing_colon() {
    let d = tempfile::tempdir().unwrap();
    let f = write(d.path(), "code.rs", "pub fn a\nprivate b\npub fn c\n");
    let py = write(
        d.path(),
        "t.py",
        "x = 1\nif crypto >= MAX_CRYPTO:\nclass Foo:\n",
    );
    assert_eq_grep_with_and_without_n(&["^pub", &f]); // anchored pattern must not escape the path
    assert_eq_grep_with_and_without_n(&["MAX_CRYPTO", &py]); // trailing-colon line kept intact
    assert_eq_grep_with_and_without_n(&["class", &py]);
}

#[test]
fn colon_in_filename_matches_grep() {
    let d = tempfile::tempdir().unwrap();
    let f1 = write(d.path(), "weird:name.txt", "hit\n");
    let f2 = write(d.path(), "other.txt", "hit\n");
    assert_eq_grep_with_and_without_n(&["hit", &f1, &f2]); // colon in a path must not fool the parser
}

#[test]
fn case_insensitive_and_invert_match_grep() {
    let d = tempfile::tempdir().unwrap();
    let f = write(d.path(), "i.txt", "Apple\nbanana\nAPPLE\n");
    assert_eq_grep_with_and_without_n(&["-i", "apple", &f]);
    assert_eq_grep_with_and_without_n(&["-v", "apple", &f]);
}

#[test]
fn piped_stdin_matches_grep() {
    let input = "apple\nzebra\napple pie\n";
    let feed = |cmd: &mut Command| {
        let mut c = cmd
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .spawn()
            .expect("spawn");
        c.stdin.take().unwrap().write_all(input.as_bytes()).unwrap();
        String::from_utf8_lossy(&c.wait_with_output().unwrap().stdout).into_owned()
    };
    for args in [vec!["apple"], vec!["-n", "apple"]] {
        let mut rtk_args = vec!["grep"];
        rtk_args.extend_from_slice(&args);
        let rtk = feed(common::rtk_command().args(&rtk_args));
        let grep = feed(common::native_command("grep").args(&args));
        assert_eq!(rtk, grep, "piped stdin mismatch for {args:?}");
    }
}

// Regression: `-m` is GNU grep's --max-count (stop after N matches), not RTK's
// --max display cap. RTK must forward `-m N` to grep so the scan actually stops
// at N — i.e. `rtk grep -m N` equals `grep -m N` (checked with and without -n).
// Covers `-m` leading and trailing. With the short bound to --max, `-m` was
// swallowed and never reached grep, so the output diverged.
#[test]
fn dash_m_max_count_matches_grep_n() {
    let d = tempfile::tempdir().unwrap();
    let f = write(d.path(), "m.txt", "hit1\nhit2\nhit3\nhit4\nhit5\n");
    assert_eq_grep_with_and_without_n(&["-m", "2", "hit", &f]); // -m leading
    assert_eq_grep_with_and_without_n(&["hit", &f, "-m", "3"]); // -m trailing
    assert_eq_grep_with_and_without_n(&["-m", "9", "hit", &f]); // N >= total: no truncation, all 5
}

// `--max-count` is per file, so the multi-file case is the one that motivates the
// fix: each file must be independently capped and the grouped output must still
// equal `grep -m N` (with and without -n).
#[test]
fn dash_m_max_count_is_per_file_like_grep_n() {
    let d = tempfile::tempdir().unwrap();
    let f1 = write(d.path(), "a.txt", "hit\nhit\nhit\n");
    let f2 = write(d.path(), "b.txt", "hit\nhit\nhit\n");
    assert_eq_grep_with_and_without_n(&["-m", "2", "hit", &f1, &f2]); // 2 per file, both files
}

// Regression: the `-l` short used to be bound to RTK's --max-len, so `grep -l PAT`
// made clap read PAT as a usize and error out (0% savings via raw fallback).
// `-l` is GNU grep's --files-with-matches; `rtk grep -l` must list exactly what
// `grep -l` lists (explicit file args => deterministic order), modulo the shared-prefix
// fold. Also covers `-l` trailing (arg-order sensitivity) and `-L` (--files-without-match).
#[test]
fn dash_l_and_dash_cap_l_match_grep() {
    let d = tempfile::tempdir().unwrap();
    let f1 = write(d.path(), "hit1.txt", "alpha\ntenant_id here\n");
    let f2 = write(d.path(), "miss.txt", "nothing to see\n");
    let f3 = write(d.path(), "hit2.txt", "tenant_id again\n");
    let f4 = write(d.path(), "port.txt", "listen on 8080\n");

    assert_eq_grep_file_list(&["-l", "tenant_id", &f1, &f2, &f3]); // -l leading (the token that broke)
    assert_eq_grep_file_list(&["tenant_id", &f1, &f2, &f3, "-l"]); // -l trailing
    assert_eq_grep_file_list(&["-L", "tenant_id", &f1, &f2, &f3]); // -L files-without-match

    // A numeric pattern is the only form that failed silently: bound to `usize`,
    // `-l` swallowed it as max_len and read the first path as the pattern, so rtk
    // printed nothing and exited 1 while grep listed the file. A non-numeric
    // pattern stops at clap's parse error and falls back to raw grep, which is
    // byte-identical here and so invisible to the assertions above.
    assert_eq_grep_file_list(&["-l", "8080", &f4, &f2]);
    assert_eq_grep_file_list(&["-L", "8080", &f4, &f2]);
}
