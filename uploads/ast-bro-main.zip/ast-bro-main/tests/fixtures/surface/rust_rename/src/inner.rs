pub struct Bar;
